﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Entidades.Clases;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Base_Datos.Conexion_DB
{
    public class Acceso_Datos
    {
        //segundo intento fail :-( 
      //  public static string Mi_Conexion;
      //  public Acceso_Datos()
       // {
       // Mi_Conexion = ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
       // }


       public static string Mi_Conexion = "server=LAPTOP-COTRQ0EE\\SQLEXPRESS; database=Faro ; integrated security = true";

        public static List<Vendedor> obtener_datos_vendedores()
        {
            //Lista de Vendedores
            List<Vendedor> lista_vendedores = new List<Vendedor>();

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "Select Identificacion, Nombre, PrimerApellido, SegundoApellido from Vendedor";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return lista_vendedores;
            }

            //Almaceno lo que devuelve el comando al ejecutarse
            try
            {
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al verificar el vendedor en la base de datos");
                mi_coneccion.Close();
                return lista_vendedores;
            }

            //si hay registros
            if (reader.HasRows)
            {
                //Mientras que haya algo leer
                while (reader.Read())
                {
                    Vendedor nuevo_vendedor = new Vendedor();
                    nuevo_vendedor.Ident_Vend = reader.GetString(0);
                    nuevo_vendedor.Nombre_Vend = reader.GetString(1);
                    nuevo_vendedor.Prim_Apell = reader.GetString(2);
                    nuevo_vendedor.Seg_Apell = reader.IsDBNull(3) ? string.Empty : reader.GetString(3);
                    lista_vendedores.Add(nuevo_vendedor);
                }
            }

            mi_coneccion.Close();

            return lista_vendedores;

        }

        //---------------------------------------------------------------------------------------------
        //
        public static bool articulo_existe(int Idarticulo)
        {
            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "select IdArticulo from articulo where IdArticulo = @Idart";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@Idart", Idarticulo.ToString());
            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return false;
            }

            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al verificar el artículo en la base de datos");
                mi_coneccion.Close();
                return false;
            }
            //si hay registros
            if (reader.HasRows)
            {
                mi_coneccion.Close();
                return true;

            }
            else
            {
                mi_coneccion.Close();
                return false;
            }
        }

        //-----------------------------------------------------------------------------------------

        public static void articulo_insertar(Articulo nuevo_articulo)
        {
            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "insert into Articulo (IdArticulo, Descripcion, Activo, PrecioVendedor, " +
                "PrecioFinal, CantidadDisponible) Values (@Idart, @Desc, @Act, @Prevend, @Prefin, @Cantdisp)";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@Idart", nuevo_articulo.Id_Articulo);
            comando_sql.Parameters.AddWithValue("@Desc", nuevo_articulo.Descripcion);
            comando_sql.Parameters.AddWithValue("@Act", nuevo_articulo.Activo);
            comando_sql.Parameters.AddWithValue("@Prevend", nuevo_articulo.Precio_Vend);
            comando_sql.Parameters.AddWithValue("@Prefin", nuevo_articulo.Precio_Final);
            comando_sql.Parameters.AddWithValue("@Cantdisp", nuevo_articulo.Cantidad_Disponible);

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return;
            }
            try
            {
                comando_sql.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al insertar el artículo en la base de datos");
                mi_coneccion.Close();
                return;
            }
            mi_coneccion.Close();
        }

        //-----------------------------------------------------------------------------------------
        public static bool Vendedor_existe(string Idvendedor)
        {

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "select Identificacion from Vendedor where Identificacion = @Idvend";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@Idvend", Idvendedor);



            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return false;
            }

            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al verificar vendedor en la base de datos");
                mi_coneccion.Close();
                return false;
            }

            //si hay registros

            if (reader.HasRows)
            {
                mi_coneccion.Close();
                return true;

            }
            else
            {
                mi_coneccion.Close();
                return false;
            }
        }


        //---------------------------------------------------------------------------------


        public static void vendedor_insertar(Vendedor nuevo_vendedor)
        {
            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "insert into Vendedor (Identificacion, Nombre, PrimerApellido, SegundoApellido, " +
                "FechaNacimiento, Genero, FechaIngreso) Values (@Id, @Nom, @PrimA, @SegunA, @Fnac, @Gen, @Fing)";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@Id", nuevo_vendedor.Ident_Vend);
            comando_sql.Parameters.AddWithValue("@Nom", nuevo_vendedor.Nombre_Vend);
            comando_sql.Parameters.AddWithValue("@PrimA", nuevo_vendedor.Prim_Apell);
            comando_sql.Parameters.AddWithValue("@SegunA", nuevo_vendedor.Seg_Apell);
            comando_sql.Parameters.AddWithValue("@Fnac", nuevo_vendedor.Fecha_Nac);
            comando_sql.Parameters.AddWithValue("@Gen", nuevo_vendedor.Genero);
            comando_sql.Parameters.AddWithValue("@Fing", nuevo_vendedor.Fecha_ing);

            try
            {
                mi_coneccion.Open();  //poner try catch a esto

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return;

            }
            try
            {
                comando_sql.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al insertar en la base de datos");
                mi_coneccion.Close();
                return;
            }
            mi_coneccion.Close();
        }

        //---------------------------------------------------------------------------------

        public static List<Articulo> obtener_datos_articulos() //esta función retorna una lista de artículos
        {

            //Lista de Articulos
            List<Articulo> lista_articulos = new List<Articulo>();
            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "select IdArticulo, Descripcion, PrecioVendedor, PrecioFinal, " +
                "CantidadDisponible from Articulo where Activo = 1";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return lista_articulos;
            }
            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al leer artículos de la base de datos");
                mi_coneccion.Close();
                return lista_articulos;
            }

            //si hay registros
            if (reader.HasRows)
            {
                //Mientras que haya algo leer
                while (reader.Read())
                {
                    Articulo nuevo_articulo = new Articulo();
                    nuevo_articulo.Id_Articulo = reader.GetInt32(0);
                    nuevo_articulo.Descripcion = reader.GetString(1);
                    nuevo_articulo.Precio_Vend = reader.GetDecimal(2);
                    nuevo_articulo.Precio_Final = reader.GetDecimal(3);
                    nuevo_articulo.Cantidad_Disponible = reader.GetInt32(4);
                    lista_articulos.Add(nuevo_articulo);

                }
            }
            mi_coneccion.Close();
            return lista_articulos;
        }
        public static Vendedor obtener_datos_un_vendedor(string Idvendedor)
        {
            Vendedor vendedor_seleccionado = new Vendedor();

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "Select Identificacion, Nombre, PrimerApellido, SegundoApellido from Vendedor" +
                " where Identificacion = @Idvend";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@Idvend", Idvendedor);

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return vendedor_seleccionado;
            }
            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al leer vendedor de la base de datos");
                mi_coneccion.Close();
                return vendedor_seleccionado;
            }

            //Vendedor vendedor_seleccionado = new Vendedor();
            //si hay registros
            if (reader.HasRows)
            {
                _ = reader.Read();
                vendedor_seleccionado.Ident_Vend = reader.GetString(0);
                vendedor_seleccionado.Nombre_Vend = reader.GetString(1);
                vendedor_seleccionado.Prim_Apell = reader.GetString(2);
                vendedor_seleccionado.Seg_Apell = reader.IsDBNull(3) ? string.Empty : reader.GetString(3);
            }

            mi_coneccion.Close();

            return vendedor_seleccionado;

        }

        //--------------------------------------------------------------------------------------
        public static int obtener_mayor_ordencompra()
        {
            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            //

            sentencia_sql = "select isnull(Max (IdOrden),0) from OrdenCompra ";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return 0;
            }
            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al leer orden de comnpra de la base de datos");
                mi_coneccion.Close();
                return 0;
            }

            int idcompra_mayor = 0;

            //si hay registros
            if (reader.HasRows)
            {
                _ = reader.Read();
                idcompra_mayor = reader.GetInt32(0);
            }

            mi_coneccion.Close();

            return idcompra_mayor;

        }

        public static int obtener_mayor_ordencompra_x_vendedor(string IDVendedor)
        {
            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            //

            sentencia_sql = "select isnull(Max (IdOrden),0) from OrdenCompra " +
                "where Identificacion = @Idvend";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@Idvend", IDVendedor);

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return 0;
            }
            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al leer orden de compra de la base de datos");
                mi_coneccion.Close();
                return 0;
            }

            int idcompra_mayor = 0;

            //si hay registros
            if (reader.HasRows)
            {
                _ = reader.Read();
                idcompra_mayor = reader.GetInt32(0);
            }

            mi_coneccion.Close();

            return idcompra_mayor;

        }


        public static int obtener_mayor_detalle()
        {

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            //

            sentencia_sql = "select isnull(Max (IdDetalle),0) from OrdenCompraDetalle ";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;


            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return 0;
            }
            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al leer detalles de la base de datos");
                mi_coneccion.Close();
                return 0;
            }

            int iddetalle_mayor = 0;

            //si hay registros
            if (reader.HasRows)
            {
                _ = reader.Read();
                iddetalle_mayor = reader.GetInt32(0);
            }

            mi_coneccion.Close();

            return iddetalle_mayor;

        }

        //-----------------------------------------------------------------------------------

        public static void ordencompra_insertar(OrdenCompra nueva_orden)
        {

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "insert into OrdenCompra (IdOrden, Identificacion, Fecha) Values (@idorden, @ident, @fecha)";

            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@idorden", nueva_orden.Id_Compra);
            comando_sql.Parameters.AddWithValue("@ident", nueva_orden.Vendedor);
            comando_sql.Parameters.AddWithValue("@fecha", nueva_orden.Fecha);
            try
            {

                mi_coneccion.Open();  //poner try catch a esto
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return;
            }
            try
            {
                comando_sql.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al insertar la orden de compra en la base de datos");
                mi_coneccion.Close();
                return;
            }

            mi_coneccion.Close();

        }

        //------------------------------------------------------------------------------------------
        public static void detalle_ordencompra_insertar(List<OrdenCompraDetalle> lista_detalle)
        {

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "insert into OrdenCompraDetalle (IdDetalle, IdOrden, IdArticulo, CantidadArticulo, PrecioVendedor, PrecioFinal)" +
                " Values (@IdDetalle, @IdOrden, @IdArticulo, @CantidadArticulo, @PrecioVendedor, @PrecioFinal)";

            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return;
            }


            foreach (OrdenCompraDetalle nuevo_detalle in lista_detalle)
            {

                comando_sql.Parameters.Clear();
                comando_sql.Parameters.AddWithValue("@IdDetalle", nuevo_detalle.IdDetalle);
                comando_sql.Parameters.AddWithValue("@IdOrden", nuevo_detalle.Id_Compra);
                comando_sql.Parameters.AddWithValue("@IdArticulo", nuevo_detalle.Id_Articulo);
                comando_sql.Parameters.AddWithValue("@CantidadArticulo", nuevo_detalle.Cantidad);
                comando_sql.Parameters.AddWithValue("@PrecioVendedor", nuevo_detalle.Precio_Vend);
                comando_sql.Parameters.AddWithValue("@PrecioFinal", nuevo_detalle.Precio_Final);

                try
                {
                    comando_sql.ExecuteNonQuery();// este se usa cuando se ejecuta un update o un insert
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message, "Error al insertar el detalle a la base de datos");
                    mi_coneccion.Close();
                    return;
                }
            }

            mi_coneccion.Close();

        }

        //----------------------------------------------------------------
        public static void actualizar_inventario(List<Articulo> lista_articulos)
        {

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "update Articulo set CantidadDisponible = @CantidadDisponible where IdArticulo = @IdArticulo";

            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;


            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return;
            }



            foreach (Articulo articulo_inv in lista_articulos)
            {

                comando_sql.Parameters.Clear();
                comando_sql.Parameters.AddWithValue("@CantidadDisponible", articulo_inv.Cantidad_Disponible);
                comando_sql.Parameters.AddWithValue("@IdArticulo", articulo_inv.Id_Articulo);

                try
                {
                    comando_sql.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message, "Error al actualizar el inventario");
                    mi_coneccion.Close();
                    return;
                }

            }

            mi_coneccion.Close();

        }
        //-----------------------------------
        public static List<OrdenCompra> obtener_datos_ordencompra()
        {
            //Lista de Vendedores
            List<OrdenCompra> lista_ordenes = new List<OrdenCompra>();

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "select IdOrden from ordencompra";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return lista_ordenes;
            }

            //Almaceno lo que devuelve el comando al ejecutarse
            try
            {
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al verificar la lista de órdenes en la base de datos");
                mi_coneccion.Close();
                return lista_ordenes;
            }

            //si hay registros
            if (reader.HasRows)
            {
                //Mientras que haya algo leer
                while (reader.Read())
                {
                    OrdenCompra nueva_orden = new OrdenCompra();
                    nueva_orden.Id_Compra = reader.GetInt32(0);
                    lista_ordenes.Add(nueva_orden);
                }
            }

            mi_coneccion.Close();

            return lista_ordenes;

        }

        public static List<OrdenCompra> obtener_datos_ordencompra_x_vendedor(string IDVendedor)
        {
            //Lista de Vendedores
            List<OrdenCompra> lista_ordenes = new List<OrdenCompra>();

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "select IdOrden from ordencompra " +
                " where Identificacion = @Idvend";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@Idvend", IDVendedor);

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return lista_ordenes;
            }

            //Almaceno lo que devuelve el comando al ejecutarse
            try
            {
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al verificar la lista de órdenes en la base de datos");
                mi_coneccion.Close();
                return lista_ordenes;
            }

            //si hay registros
            if (reader.HasRows)
            {
                //Mientras que haya algo leer
                while (reader.Read())
                {
                    OrdenCompra nueva_orden = new OrdenCompra();
                    nueva_orden.Id_Compra = reader.GetInt32(0);
                    lista_ordenes.Add(nueva_orden);
                }
            }

            mi_coneccion.Close();

            return lista_ordenes;

        }

        public static OrdenCompra obtener_datos_una_ordencompra(int Idcompra)
        {
            OrdenCompra ordencompra_seleccionado = new OrdenCompra();

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "select O.IdOrden, O.Identificacion, O.fecha, V.Nombre, V.PrimerApellido, " +
                " V.SegundoApellido from OrdenCompra O, Vendedor V " +
                " WHERE O.Identificacion = V.Identificacion and O.IdOrden = @IdOrd";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@IdOrd", Idcompra);

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return ordencompra_seleccionado;
            }
            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al leer ordencompra de la base de datos");
                mi_coneccion.Close();
                return ordencompra_seleccionado;
            }

            //si hay registros
            if (reader.HasRows)
            {
                _ = reader.Read();
                ordencompra_seleccionado.Id_Compra = reader.GetInt32(0);
                ordencompra_seleccionado.Vendedor = reader.GetString(1);
                ordencompra_seleccionado.Fecha = reader.GetDateTime(2);
                ordencompra_seleccionado.Nombre_Vend = reader.GetString(3);
                ordencompra_seleccionado.Prim_Apell = reader.GetString(4);
                ordencompra_seleccionado.Seg_Apell = reader.IsDBNull(3) ? string.Empty : reader.GetString(5);
            }

            mi_coneccion.Close();

            return ordencompra_seleccionado;

        }

        public static List<OrdenCompraDetalle> obtener_datos_detalleordencompra(int Idcompra)
        {
            //Lista de Vendedores
            List<OrdenCompraDetalle> lista_detalleorden = new List<OrdenCompraDetalle>();

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "select D.IdDetalle, D.IdOrden, D.IdArticulo, D.CantidadArticulo, " +
               " D.PrecioVendedor, D. PrecioFinal, A.Descripcion from OrdenCompraDetalle D, " +
               " Articulo A where D.IdArticulo = A.IdArticulo and IdOrden = @IdOrd";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@IdOrd", Idcompra);

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return lista_detalleorden;
            }

            //Almaceno lo que devuelve el comando al ejecutarse
            try
            {
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al verificar la lista de órdenes en la base de datos");
                mi_coneccion.Close();
                return lista_detalleorden;
            }

            //si hay registros
            if (reader.HasRows)
            {
                //Mientras que haya algo leer
                while (reader.Read())
                {
                    OrdenCompraDetalle nuevo_detalle = new OrdenCompraDetalle();
                    nuevo_detalle.IdDetalle = reader.GetInt32(0); 
                    nuevo_detalle.Id_Compra = Idcompra;
                    nuevo_detalle.Id_Articulo = reader.GetInt32(2);
                    nuevo_detalle.Cantidad = reader.GetInt32(3);
                    nuevo_detalle.Precio_Vend = reader.GetDecimal(4);
                    nuevo_detalle.Precio_Final = reader.GetDecimal(5);
                    nuevo_detalle.Descripcion = reader.GetString(6);

                    lista_detalleorden.Add(nuevo_detalle);
                }
            }

            mi_coneccion.Close();

            return lista_detalleorden;

        }

        //-----------------------------------------------------------------------------------------
        public static List<Articulo> obtener_datostotales_articulos() //esta función retorna una lista de artículos
        {

            //Lista de Articulos
            List<Articulo> lista_articulos = new List<Articulo>();
            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //Esta variable almacena lo que devuelve el comando
            SqlDataReader reader;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "select IdArticulo, Descripcion, Activo, PrecioVendedor, PrecioFinal, " +
                "CantidadDisponible from Articulo";
            //Se le indica al comando los parámetros:
            //1. Que es un texto
            //2. EL SQL que se quiere ejecutar
            //3. La conexión
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return lista_articulos;
            }
            try
            {
                //Almaceno lo que devuelve el comando al ejecutarse
                reader = comando_sql.ExecuteReader();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al leer artículos de la base de datos");
                mi_coneccion.Close();
                return lista_articulos;
            }

            //si hay registros
            if (reader.HasRows)
            {
                //Mientras que haya algo leer
                while (reader.Read())
                {
                    Articulo nuevo_articulo = new Articulo();
                    nuevo_articulo.Id_Articulo = reader.GetInt32(0);
                    nuevo_articulo.Descripcion = reader.GetString(1);
                    nuevo_articulo.Activo = reader.GetBoolean(2);
                    nuevo_articulo.Precio_Vend = reader.GetDecimal(3);
                    nuevo_articulo.Precio_Final = reader.GetDecimal(4);
                    nuevo_articulo.Cantidad_Disponible = reader.GetInt32(5);
                    lista_articulos.Add(nuevo_articulo);

                }
            }
            mi_coneccion.Close();
            return lista_articulos;
        }
        public static void actualizar_articulos_update(int idArticulo, bool activo, decimal precio_vendedor, decimal precio_final, int cantidad_disponible)
        {

            //Este variable tiene el comando que se va a enviar a la base de datos
            SqlCommand comando_sql = new SqlCommand();

            //Este es el sql que se va a enviar como parte del comando
            string sentencia_sql;

            //defino mi conexión
            SqlConnection mi_coneccion = new SqlConnection(Mi_Conexion);

            //Defino el sql que quiero ejecutar
            sentencia_sql = "update Articulo set Activo = @Activo, PrecioVendedor = @PrecioV, " +
                " PrecioFinal = @PrecioF, CantidadDisponible = @CD where IdArticulo = @IdArt";
            comando_sql.CommandType = CommandType.Text;
            comando_sql.CommandText = sentencia_sql;
            comando_sql.Connection = mi_coneccion;
            comando_sql.Parameters.AddWithValue("@Activo", activo);
            comando_sql.Parameters.AddWithValue("@PrecioV", precio_vendedor);
            comando_sql.Parameters.AddWithValue("@PrecioF", precio_final);
            comando_sql.Parameters.AddWithValue("@CD", cantidad_disponible);
            comando_sql.Parameters.AddWithValue("@IdArt", idArticulo);

            try
            {
                mi_coneccion.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al conectarse con la base de datos");
                return;
            }

            try
            {
                comando_sql.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error al actualizar el inventario");
                mi_coneccion.Close();
                return;
            }
            mi_coneccion.Close();
        }
    }



}




// poner try catch n los open de la conexión "no se pudo establecer la conexión a la base de datos"

//poner try catch en los excecutenonquery "la operación no fue posible"