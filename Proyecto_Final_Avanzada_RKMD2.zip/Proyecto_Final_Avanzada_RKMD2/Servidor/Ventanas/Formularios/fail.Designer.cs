﻿
namespace Ventanas
{
    partial class Menu_Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu_Inicio));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncerrar = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnsalir = new System.Windows.Forms.Button();
            this.panelmenu = new System.Windows.Forms.Panel();
            this.panel_panel_servidor = new System.Windows.Forms.Panel();
            this.btnreg_art = new System.Windows.Forms.Button();
            this.btn_consultar_inventario = new System.Windows.Forms.Button();
            this.txtestado = new System.Windows.Forms.TextBox();
            this.btn_actualizar_inventario = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnreg_vendedores = new System.Windows.Forms.Button();
            this.richTextBox_conectados = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btniniciar = new System.Windows.Forms.Button();
            this.btnservidor1 = new System.Windows.Forms.Button();
            this.btndetener = new System.Windows.Forms.Button();
            this.panelcentral = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).BeginInit();
            this.panelmenu.SuspendLayout();
            this.panel_panel_servidor.SuspendLayout();
            this.panelcentral.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btncerrar);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1162, 48);
            this.panel1.TabIndex = 1;
            // 
            // btncerrar
            // 
            this.btncerrar.Image = ((System.Drawing.Image)(resources.GetObject("btncerrar.Image")));
            this.btncerrar.Location = new System.Drawing.Point(1120, 6);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(34, 32);
            this.btncerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btncerrar.TabIndex = 2;
            this.btncerrar.TabStop = false;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(274, 223);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "ESTE NOOOOOOOO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(77, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "MENÚ INICIAL";
            // 
            // btnsalir
            // 
            this.btnsalir.BackColor = System.Drawing.Color.DimGray;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnsalir.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsalir.Location = new System.Drawing.Point(97, 515);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(157, 34);
            this.btnsalir.TabIndex = 0;
            this.btnsalir.Text = "SALIR";
            this.btnsalir.UseVisualStyleBackColor = false;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // panelmenu
            // 
            this.panelmenu.BackColor = System.Drawing.SystemColors.ControlText;
            this.panelmenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelmenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelmenu.Controls.Add(this.panel_panel_servidor);
            this.panelmenu.Location = new System.Drawing.Point(0, 48);
            this.panelmenu.Name = "panelmenu";
            this.panelmenu.Size = new System.Drawing.Size(344, 563);
            this.panelmenu.TabIndex = 5;
            // 
            // panel_panel_servidor
            // 
            this.panel_panel_servidor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_panel_servidor.Controls.Add(this.btnsalir);
            this.panel_panel_servidor.Controls.Add(this.btnreg_art);
            this.panel_panel_servidor.Controls.Add(this.btn_consultar_inventario);
            this.panel_panel_servidor.Controls.Add(this.txtestado);
            this.panel_panel_servidor.Controls.Add(this.btn_actualizar_inventario);
            this.panel_panel_servidor.Controls.Add(this.label4);
            this.panel_panel_servidor.Controls.Add(this.btnreg_vendedores);
            this.panel_panel_servidor.Controls.Add(this.richTextBox_conectados);
            this.panel_panel_servidor.Controls.Add(this.label2);
            this.panel_panel_servidor.Controls.Add(this.btniniciar);
            this.panel_panel_servidor.Controls.Add(this.btnservidor1);
            this.panel_panel_servidor.Controls.Add(this.btndetener);
            this.panel_panel_servidor.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_panel_servidor.Location = new System.Drawing.Point(0, 0);
            this.panel_panel_servidor.Name = "panel_panel_servidor";
            this.panel_panel_servidor.Size = new System.Drawing.Size(342, 559);
            this.panel_panel_servidor.TabIndex = 37;
            // 
            // btnreg_art
            // 
            this.btnreg_art.BackColor = System.Drawing.Color.DimGray;
            this.btnreg_art.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnreg_art.FlatAppearance.BorderSize = 2;
            this.btnreg_art.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkBlue;
            this.btnreg_art.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnreg_art.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreg_art.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnreg_art.Location = new System.Drawing.Point(53, 342);
            this.btnreg_art.Name = "btnreg_art";
            this.btnreg_art.Size = new System.Drawing.Size(238, 34);
            this.btnreg_art.TabIndex = 1;
            this.btnreg_art.Text = "Registrar Artículos";
            this.btnreg_art.UseVisualStyleBackColor = false;
            this.btnreg_art.Click += new System.EventHandler(this.btnreg_art_Click);
            // 
            // btn_consultar_inventario
            // 
            this.btn_consultar_inventario.BackColor = System.Drawing.Color.DimGray;
            this.btn_consultar_inventario.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_consultar_inventario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btn_consultar_inventario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_consultar_inventario.Location = new System.Drawing.Point(53, 459);
            this.btn_consultar_inventario.Name = "btn_consultar_inventario";
            this.btn_consultar_inventario.Size = new System.Drawing.Size(238, 34);
            this.btn_consultar_inventario.TabIndex = 6;
            this.btn_consultar_inventario.Text = "Consultar Inventario";
            this.btn_consultar_inventario.UseVisualStyleBackColor = false;
            // 
            // txtestado
            // 
            this.txtestado.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtestado.Location = new System.Drawing.Point(97, 124);
            this.txtestado.Name = "txtestado";
            this.txtestado.ReadOnly = true;
            this.txtestado.Size = new System.Drawing.Size(225, 20);
            this.txtestado.TabIndex = 41;
            // 
            // btn_actualizar_inventario
            // 
            this.btn_actualizar_inventario.BackColor = System.Drawing.Color.DimGray;
            this.btn_actualizar_inventario.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_actualizar_inventario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btn_actualizar_inventario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_actualizar_inventario.Location = new System.Drawing.Point(53, 404);
            this.btn_actualizar_inventario.Name = "btn_actualizar_inventario";
            this.btn_actualizar_inventario.Size = new System.Drawing.Size(238, 34);
            this.btn_actualizar_inventario.TabIndex = 5;
            this.btn_actualizar_inventario.Text = "Actualizar Inventario";
            this.btn_actualizar_inventario.UseVisualStyleBackColor = false;
            this.btn_actualizar_inventario.Click += new System.EventHandler(this.btn_actualizar_inventario_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(24, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 18);
            this.label4.TabIndex = 40;
            this.label4.Text = "Estado";
            // 
            // btnreg_vendedores
            // 
            this.btnreg_vendedores.BackColor = System.Drawing.Color.DimGray;
            this.btnreg_vendedores.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnreg_vendedores.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnreg_vendedores.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnreg_vendedores.Location = new System.Drawing.Point(53, 290);
            this.btnreg_vendedores.Name = "btnreg_vendedores";
            this.btnreg_vendedores.Size = new System.Drawing.Size(237, 34);
            this.btnreg_vendedores.TabIndex = 2;
            this.btnreg_vendedores.Text = "Registrar Vendedores";
            this.btnreg_vendedores.UseVisualStyleBackColor = false;
            this.btnreg_vendedores.Click += new System.EventHandler(this.btnreg_vendedores_Click);
            // 
            // richTextBox_conectados
            // 
            this.richTextBox_conectados.Location = new System.Drawing.Point(15, 171);
            this.richTextBox_conectados.Name = "richTextBox_conectados";
            this.richTextBox_conectados.Size = new System.Drawing.Size(307, 96);
            this.richTextBox_conectados.TabIndex = 39;
            this.richTextBox_conectados.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(128, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 19);
            this.label2.TabIndex = 38;
            this.label2.Text = "BITACORA";
            // 
            // btniniciar
            // 
            this.btniniciar.BackColor = System.Drawing.Color.Black;
            this.btniniciar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btniniciar.FlatAppearance.BorderSize = 3;
            this.btniniciar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.btniniciar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btniniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btniniciar.ForeColor = System.Drawing.Color.Green;
            this.btniniciar.Location = new System.Drawing.Point(39, 75);
            this.btniniciar.Name = "btniniciar";
            this.btniniciar.Size = new System.Drawing.Size(109, 34);
            this.btniniciar.TabIndex = 35;
            this.btniniciar.Text = "INICIAR";
            this.btniniciar.UseVisualStyleBackColor = false;
            // 
            // btnservidor1
            // 
            this.btnservidor1.BackColor = System.Drawing.Color.DimGray;
            this.btnservidor1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnservidor1.FlatAppearance.BorderSize = 3;
            this.btnservidor1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnservidor1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnservidor1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnservidor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnservidor1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnservidor1.Location = new System.Drawing.Point(39, 19);
            this.btnservidor1.Name = "btnservidor1";
            this.btnservidor1.Size = new System.Drawing.Size(283, 34);
            this.btnservidor1.TabIndex = 7;
            this.btnservidor1.Text = "Conección  al Servidor";
            this.btnservidor1.UseVisualStyleBackColor = false;
            this.btnservidor1.Click += new System.EventHandler(this.btnservidor1_Click);
            // 
            // btndetener
            // 
            this.btndetener.BackColor = System.Drawing.Color.Black;
            this.btndetener.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btndetener.FlatAppearance.BorderSize = 3;
            this.btndetener.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.btndetener.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btndetener.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndetener.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btndetener.Location = new System.Drawing.Point(202, 78);
            this.btndetener.Name = "btndetener";
            this.btndetener.Size = new System.Drawing.Size(120, 31);
            this.btndetener.TabIndex = 36;
            this.btndetener.Text = "DETENER";
            this.btndetener.UseVisualStyleBackColor = false;
            this.btndetener.Click += new System.EventHandler(this.btndetener_Click_1);
            // 
            // panelcentral
            // 
            this.panelcentral.AutoScroll = true;
            this.panelcentral.AutoSize = true;
            this.panelcentral.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelcentral.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelcentral.BackgroundImage")));
            this.panelcentral.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelcentral.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelcentral.Controls.Add(this.label1);
            this.panelcentral.Enabled = false;
            this.panelcentral.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelcentral.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panelcentral.Location = new System.Drawing.Point(341, 48);
            this.panelcentral.MaximumSize = new System.Drawing.Size(821, 563);
            this.panelcentral.MinimumSize = new System.Drawing.Size(821, 563);
            this.panelcentral.Name = "panelcentral";
            this.panelcentral.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.panelcentral.Size = new System.Drawing.Size(821, 563);
            this.panelcentral.TabIndex = 6;
            // 
            // Menu_Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1162, 613);
            this.Controls.Add(this.panelcentral);
            this.Controls.Add(this.panelmenu);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Menu_Inicio";
            this.Text = "Menu_Inicio";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).EndInit();
            this.panelmenu.ResumeLayout(false);
            this.panel_panel_servidor.ResumeLayout(false);
            this.panel_panel_servidor.PerformLayout();
            this.panelcentral.ResumeLayout(false);
            this.panelcentral.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.Panel panelmenu;
        private System.Windows.Forms.Button btn_consultar_inventario;
        private System.Windows.Forms.Button btn_actualizar_inventario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnreg_vendedores;
        private System.Windows.Forms.Button btnreg_art;
        private System.Windows.Forms.PictureBox btncerrar;
        private System.Windows.Forms.Button btnservidor1;
        private System.Windows.Forms.Button btniniciar;
        private System.Windows.Forms.Panel panel_panel_servidor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btndetener;
        private System.Windows.Forms.RichTextBox richTextBox_conectados;
        private System.Windows.Forms.TextBox txtestado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelcentral;
    }
}