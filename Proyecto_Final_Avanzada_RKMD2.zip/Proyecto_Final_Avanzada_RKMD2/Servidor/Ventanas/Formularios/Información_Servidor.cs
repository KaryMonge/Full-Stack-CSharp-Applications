﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using Newtonsoft.Json;
using System.IO;
using static Negocios.Utilidades.Extend_Bd;
using Base_Datos.Conexion_DB;
using Entidades.Clases;


namespace Ventanas.Formularios
{
    public partial class Información_Servidor : Form
    {

        TcpListener tcpListener;
        Thread subprocesolisten;
        Acceso_Datos acceso_Datos;
        bool inicar_servidor;
        Datagrid_Bit_Delegado Mod_Datagrid_B;
        Datagrid_Cli_Delegado Mod_Datagrid_C;

        public Información_Servidor()
        {
            InitializeComponent();
            acceso_Datos = new Acceso_Datos();
            btndetener.Enabled = false;

        }
        //Metodos delegados del profe 
        private delegate void Datagrid_Bit_Delegado(string texto);
        private delegate void Datagrid_Cli_Delegado(string texto, bool agregar);

        private void btniniciar_Click(object sender, EventArgs e)
        {
            IPAddress local = IPAddress.Parse("127.0.0.1");
            tcpListener = new TcpListener(local, 30000);
            inicar_servidor = true;

            subprocesolisten = new Thread(new ThreadStart(client_listener));
            subprocesolisten.Start();
            subprocesolisten.IsBackground = true;
            txtestado.Text = "Escuchando clientes... en (127.0.0.1, 30000)";
            txtestado.ForeColor = Color.Green;
            btniniciar.Enabled = false;
            btndetener.Enabled = true;

            dataGridView_Bitacora.Text = "Servidor iniciado... en (127.0.0.1, 30000)";
            dataGridView_Bitacora.Rows.Add(Environment.NewLine);


        }

        private void client_listener()
        {
            tcpListener.Start();
            while (inicar_servidor)
            {
                //Se bloquea hasta que un cliente se haya conectado al servidor 
                TcpClient client = tcpListener.AcceptTcpClient();
                /*Se crea un nuevo hilo para manejar la comunicación con los clientes que se conectan al servidor*/
                Thread clientThread = new Thread(new ParameterizedThreadStart(intercomunicacion_client));
                clientThread.Start(client);
            }
        }
        
        private void intercomunicacion_client(object cliente)
        {
            TcpClient TC_cliente = (TcpClient)cliente;
            StreamReader reader = new StreamReader(TC_cliente.GetStream());
            StreamWriter servidorStreamWriter = new StreamWriter(TC_cliente.GetStream());//El StreamWriter debe ser único por subproceso y por cliente por eso se pasa por referencia

            while (inicar_servidor)
            {
                try
                {
                    //Bloqueo hasta recibir mensaje de clientes
                    var mesage = reader.ReadLine();
                    //Deserialización del objeto recibido por medio de json
                    Sockets<object> recibir = JsonConvert.DeserializeObject<Sockets<object>>(mesage);
                    Select_Op(recibir.Metod, mesage, ref servidorStreamWriter);
                }
                catch (Exception e)
                {
                    //Mensaje de error 
                    MessageBox.Show("ayyy papaaaaaaá se le cayó el servidor");
                    break;
                }
            }

            TC_cliente.Close();
        }


        private void btndetener_Click(object sender, EventArgs e)
        {
            inicar_servidor = false;
            tcpListener.Stop();
            subprocesolisten.Abort();
            txtestado.ForeColor = Color.Red;
            txtestado.Text = "No iniciado";
            btniniciar.Enabled = true;
            btndetener.Enabled = false;
        }

        
        public void Vendedor_existe_Ventana(string IDVendedor, ref StreamWriter server_StreamWriter)
        {
            bool existe;
            existe = Vendedor_existe_Negocio(IDVendedor);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(existe));
            server_StreamWriter.Flush();

        }
        

        
        public void Vendedor_Datos_Ventana(string IDVendedor, ref StreamWriter server_StreamWriter)
        {
            Vendedor  vendedor_D;
            vendedor_D = obtener_datos_un_vendedor_Negocio(IDVendedor);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(vendedor_D));
            server_StreamWriter.Flush();
          
        }

        
        /// <param name="message">Nombre del método que se debe invocar</param>
        /// <param name="option">Mensaje enviado por el cliente</param>
        public void Select_Op(string option, string message, ref StreamWriter servidor_StreamWriter)
        {
            switch (option)
            {
                case "Conectar":
                    Sockets<string> mensajeConectar = JsonConvert.DeserializeObject<Sockets<string>>(message);// Se deserializa el objeto recibido mediante json
                    Conectar(mensajeConectar.Entity);
                    break;
                case "Vendedor":
                    Sockets<Vendedor> mostrar_vendedor = JsonConvert.DeserializeObject<Sockets<Vendedor>>(message);// Se deserializa el objeto recibido mediante json
                    //AgregarAutor(mensajeCrearAutor.Entity);
                    break;
                case "Venta":
                    Sockets<Articulo> Mostrar_articulo = JsonConvert.DeserializeObject<Sockets<Articulo>>(message);//Se deserializa el objeto recibido mediante json
                    //AgregarLibro(mensajeCrearLibro.Entity);
                    break;
                case "Desconectar":
                    Sockets<string> mensajeDesconectar = JsonConvert.DeserializeObject<Sockets<string>>(message);//Se deserializa el objeto recibido mediante json
                    Desconect(mensajeDesconectar.Entity);
                    break;
                case "Vendedor_Existe":
                    Sockets<string> mensajeVerificarVendedor = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    Vendedor_existe_Ventana(mensajeVerificarVendedor.Entity, ref servidor_StreamWriter);
                    break;
                case "Vendedor_Datos":
                    Sockets<string> mensajeDatos_Vendedor = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    Vendedor_Datos_Ventana(mensajeDatos_Vendedor.Entity, ref servidor_StreamWriter);
                    break;
                default:
                    break;
            }
        }
        private void Conectar(string Id_Vendedor)
        {
            dataGridView_Bitacora.Invoke(Mod_Datagrid_B, new object[] { Id_Vendedor + " se ha conectado..." });
            dataGridView_clientes_conectados.Invoke(Mod_Datagrid_C, new object[] { Id_Vendedor, true });

        }

        private void Desconect(string desconectado)
        {
            dataGridView_Bitacora.Invoke(Mod_Datagrid_B, new object[] { desconectado + " se ha desconectado!" });
            // dataGridView_clientes_conectados.Invoke(Mod_Datagrid_C, new object[] { obtener_vendedores_conectados, false });
        }



        private void obtener_vendedores_conectados(ref StreamWriter servidorStreamWriter)
        {
            List<Vendedor> lista_vendedores= new List<Vendedor>();

            //lista_vendedores = Acceso_Datos.obtener_datos_un_vendedor();

            servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(lista_vendedores));
            servidorStreamWriter.Flush();

        }



    }
}

