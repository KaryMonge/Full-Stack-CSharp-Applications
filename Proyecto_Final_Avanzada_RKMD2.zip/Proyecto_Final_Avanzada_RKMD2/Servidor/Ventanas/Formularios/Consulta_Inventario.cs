﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clases;

using static Negocios.Utilidades.Extend_Bd;


namespace Ventanas.Formularios
{
    public partial class Consulta_Inventario : Form
    {
        public Consulta_Inventario()
        {
            InitializeComponent();

            List<Articulo> lista_articulos = new List<Articulo>();

            lista_articulos = obtener_datostotales_articulos_Negocio();


            foreach(Articulo articulo_extraido in lista_articulos)
            {
                string Activo;
                if(articulo_extraido.Activo)
                {
                    Activo = "Sí";
                }
                else
                {
                    Activo = "No";
                }

                dataGrid_Consultar_inv.Rows.Add(articulo_extraido.Id_Articulo,articulo_extraido.Descripcion, Activo, articulo_extraido.Precio_Vend, articulo_extraido.Precio_Final,articulo_extraido.Cantidad_Disponible);
            }

        }
  
    }

}
