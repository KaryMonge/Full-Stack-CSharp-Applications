﻿
namespace Ventanas.Formularios
{
    partial class Información_Servidor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Información_Servidor));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView_clientes_conectados = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_Bitacora = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.txtestado = new System.Windows.Forms.TextBox();
            this.btniniciar = new System.Windows.Forms.Button();
            this.btndetener = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_clientes_conectados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Bitacora)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(859, 124);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Location = new System.Drawing.Point(211, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(397, 29);
            this.label1.TabIndex = 29;
            this.label1.Text = "Información del Servidor";
            // 
            // dataGridView_clientes_conectados
            // 
            this.dataGridView_clientes_conectados.AllowUserToAddRows = false;
            this.dataGridView_clientes_conectados.AllowUserToDeleteRows = false;
            this.dataGridView_clientes_conectados.AllowUserToResizeColumns = false;
            this.dataGridView_clientes_conectados.AllowUserToResizeRows = false;
            this.dataGridView_clientes_conectados.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dataGridView_clientes_conectados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dataGridView_clientes_conectados.Enabled = false;
            this.dataGridView_clientes_conectados.Location = new System.Drawing.Point(0, 287);
            this.dataGridView_clientes_conectados.Name = "dataGridView_clientes_conectados";
            this.dataGridView_clientes_conectados.Size = new System.Drawing.Size(342, 274);
            this.dataGridView_clientes_conectados.TabIndex = 30;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "LISTA DE CLIENTES CONECTADOS                ";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 300;
            // 
            // dataGridView_Bitacora
            // 
            this.dataGridView_Bitacora.AllowUserToAddRows = false;
            this.dataGridView_Bitacora.AllowUserToDeleteRows = false;
            this.dataGridView_Bitacora.AllowUserToResizeColumns = false;
            this.dataGridView_Bitacora.AllowUserToResizeRows = false;
            this.dataGridView_Bitacora.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Bitacora.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2});
            this.dataGridView_Bitacora.Enabled = false;
            this.dataGridView_Bitacora.Location = new System.Drawing.Point(502, 287);
            this.dataGridView_Bitacora.Name = "dataGridView_Bitacora";
            this.dataGridView_Bitacora.Size = new System.Drawing.Size(345, 274);
            this.dataGridView_Bitacora.TabIndex = 31;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "BITACORA";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 300;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label2.Location = new System.Drawing.Point(291, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 29);
            this.label2.TabIndex = 32;
            this.label2.Text = "Estado:";
            // 
            // txtestado
            // 
            this.txtestado.BackColor = System.Drawing.Color.Black;
            this.txtestado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtestado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtestado.ForeColor = System.Drawing.Color.White;
            this.txtestado.Location = new System.Drawing.Point(407, 31);
            this.txtestado.Name = "txtestado";
            this.txtestado.ReadOnly = true;
            this.txtestado.Size = new System.Drawing.Size(400, 26);
            this.txtestado.TabIndex = 33;
            // 
            // btniniciar
            // 
            this.btniniciar.BackColor = System.Drawing.Color.Black;
            this.btniniciar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btniniciar.FlatAppearance.BorderSize = 3;
            this.btniniciar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.btniniciar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btniniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btniniciar.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btniniciar.Location = new System.Drawing.Point(377, 298);
            this.btniniciar.Name = "btniniciar";
            this.btniniciar.Size = new System.Drawing.Size(92, 34);
            this.btniniciar.TabIndex = 34;
            this.btniniciar.Text = "INICIAR";
            this.btniniciar.UseVisualStyleBackColor = false;
            this.btniniciar.Click += new System.EventHandler(this.btniniciar_Click);
            // 
            // btndetener
            // 
            this.btndetener.BackColor = System.Drawing.Color.Black;
            this.btndetener.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btndetener.FlatAppearance.BorderSize = 3;
            this.btndetener.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.btndetener.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btndetener.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndetener.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.btndetener.Location = new System.Drawing.Point(377, 370);
            this.btndetener.Name = "btndetener";
            this.btndetener.Size = new System.Drawing.Size(92, 31);
            this.btndetener.TabIndex = 35;
            this.btndetener.Text = "DETENER";
            this.btndetener.UseVisualStyleBackColor = false;
            this.btndetener.Click += new System.EventHandler(this.btndetener_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.txtestado);
            this.panel1.Controls.Add(this.label2);
            this.panel1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Location = new System.Drawing.Point(0, 183);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(859, 82);
            this.panel1.TabIndex = 36;
            // 
            // Información_Servidor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(859, 563);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btndetener);
            this.Controls.Add(this.btniniciar);
            this.Controls.Add(this.dataGridView_Bitacora);
            this.Controls.Add(this.dataGridView_clientes_conectados);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Información_Servidor";
            this.Text = "Información_Servidor";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_clientes_conectados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Bitacora)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView_clientes_conectados;
        private System.Windows.Forms.DataGridView dataGridView_Bitacora;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtestado;
        private System.Windows.Forms.Button btniniciar;
        private System.Windows.Forms.Button btndetener;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Panel panel1;
    }
}