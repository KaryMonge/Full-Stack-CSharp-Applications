﻿using Base_Datos.Conexion_DB;
using Entidades.Clases;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ventanas.Formularios;
using Ventanas.Sub_menu;
using static Negocios.Utilidades.Extend_Bd;



namespace Ventanas

{
   
   public partial class Menu_Inicio : Form
    {
        TcpListener tcpListener;
        Thread subprocesolisten;
        Acceso_Datos acceso_Datos;
        bool inicar_servidor;


        public Menu_Inicio()
        {
            InitializeComponent();
            
        }

        private void client_listener()
        {
            tcpListener.Start();
            while (inicar_servidor)
            {
                //Se bloquea hasta que un cliente se haya conectado al servidor 
                TcpClient client = tcpListener.AcceptTcpClient();
                /*Se crea un nuevo hilo para manejar la comunicación con los clientes que se conectan al servidor*/
                Thread clientThread = new Thread(new ParameterizedThreadStart(intercomunicacion_client));
                clientThread.Start(client);
            }
        }


        private void Abrir_ventanas(Object ventanas)
        {
            if (this.panelcentral.Controls.Count > 0) this.panelcentral.Controls.RemoveAt(0);
            Form vent = ventanas as Form;
            vent.TopLevel = false;
            vent.Dock = DockStyle.Fill;
            this.panelcentral.Controls.Add(vent);
            this.panelcentral.Tag = vent;
            vent.Show();
        }

        //Metodos delegados del profe 
       // private delegate void Datagrid_Bit_Delegado(string texto);
        private delegate void richTextBox_clientes_conectados_Delegado(string texto, bool agregar);

        private void btniniciar_Click(object sender, EventArgs e)
        {
            IPAddress local = IPAddress.Parse("127.0.0.1");
            tcpListener = new TcpListener(local, 30000);
            inicar_servidor = true;

            subprocesolisten = new Thread(new ThreadStart(client_listener));
            subprocesolisten.Start();
            subprocesolisten.IsBackground = true;
            txtestado.Text = "Escuchando clientes... en (127.0.0.1, 30000)";
            txtestado.ForeColor = Color.Green;
            btniniciar.Enabled = false;
            btndetener.Enabled = true;

           


        }
        private void btnreg_art_Click(object sender, EventArgs e)
        {    
            Abrir_ventanas(new Regristro_articulos());
        }



        private void btnreg_vendedores_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Registro_Vendedores());
        }

        private void btn_actualizar_inventario_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Actualizar_inventario());
        }

        private void btncerrar_Click(object sender, EventArgs e)
        {  
                Application.Exit();
        }


        private void btnsalir_Click(object sender, EventArgs e)
        {
            var resultado = MessageBox.Show("¿Desea salir de la aplicación?", "Agregar", MessageBoxButtons.YesNo,
             MessageBoxIcon.Question);
            if (resultado == DialogResult.No)
            {
                return;
            }
            else
            {
                Application.Exit();
            }
            
        }

        private void btnservidor1_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Información_Servidor());
        }





        private void intercomunicacion_client(object cliente)
        {
            TcpClient TC_cliente = (TcpClient)cliente;
            StreamReader reader = new StreamReader(TC_cliente.GetStream());
            StreamWriter servidorStreamWriter = new StreamWriter(TC_cliente.GetStream());//El StreamWriter debe ser único por subproceso y por cliente por eso se pasa por referencia

            while (inicar_servidor)
            {
                try
                {
                    //Bloqueo hasta recibir mensaje de clientes
                    var mesage = reader.ReadLine();
                    //Deserialización del objeto recibido por medio de json
                    Sockets<object> recibir = JsonConvert.DeserializeObject<Sockets<object>>(mesage);
                  //  Select_Op(recibir.Metod, mesage, ref servidorStreamWriter);
                }
                catch (Exception e)
                {
                    //Mensaje de error 
                    MessageBox.Show("ayyy papaaaaaaá se le cayó el servidor");
                    break;
                }
            }

            TC_cliente.Close();
        }




        private void btndetener_Click(object sender, EventArgs e)
        {
            inicar_servidor = false;
            tcpListener.Stop();
            subprocesolisten.Abort();
            txtestado.ForeColor = Color.Red;
            txtestado.Text = "No iniciado";
            btniniciar.Enabled = true;
            btndetener.Enabled = false;
        }
        public void Vendedor_existe_Ventana(string IDVendedor, ref StreamWriter server_StreamWriter)
        {
            bool existe;
            existe = Vendedor_existe_Negocio(IDVendedor);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(existe));
            server_StreamWriter.Flush();

        }

        public void Vendedor_Datos_Ventana(string IDVendedor, ref StreamWriter server_StreamWriter)
        {
            Vendedor vendedor_D;
            vendedor_D = obtener_datos_un_vendedor_Negocio(IDVendedor);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(vendedor_D));
            server_StreamWriter.Flush();

        }

        private void btndetener_Click_1(object sender, EventArgs e)
        {
            inicar_servidor = false;
            tcpListener.Stop();
            subprocesolisten.Abort();
            txtestado.ForeColor = Color.Red;
            txtestado.Text = "No iniciado";
            btniniciar.Enabled = true;
            btndetener.Enabled = false;
        }


    }
    
}