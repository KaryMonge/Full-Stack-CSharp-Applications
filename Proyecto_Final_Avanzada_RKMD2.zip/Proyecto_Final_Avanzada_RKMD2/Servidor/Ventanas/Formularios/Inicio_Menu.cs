﻿using Base_Datos.Conexion_DB;
using Entidades.Clases;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ventanas.Formularios;
using Ventanas.Sub_menu;
using static Negocios.Utilidades.Extend_Bd;

//EL NUEVO


namespace Ventanas

{

    public partial class Inicio_Menu : Form
    {
        TcpListener tcpListener;
        Thread subprocesolisten;
        Acceso_Datos acceso_Datos;
        bool inicar_servidor;


        public Inicio_Menu()
        {
            InitializeComponent();
            btndetener.Enabled = false;
        }

        private void Abrir_ventanas(Object ventanas)
        {
            if (this.panelcentral.Controls.Count > 0) this.panelcentral.Controls.RemoveAt(0);
            Form vent = ventanas as Form;
            vent.TopLevel = false;
            vent.Dock = DockStyle.Fill;
            this.panelcentral.Controls.Add(vent);
            this.panelcentral.Tag = vent;
            vent.Show();
        }

        //Metodo delegados  del ejemplo de bliblioteca que dio el profesor.
        private delegate void clientes_ventana_Delegado(string texto);

        
        private void intercomunicacion_client(object cliente)
        {
            TcpClient TC_cliente = (TcpClient)cliente;
            StreamReader reader = new StreamReader(TC_cliente.GetStream());
            StreamWriter servidorStreamWriter = new StreamWriter(TC_cliente.GetStream());//El StreamWriter debe ser único por subproceso y por cliente por eso se pasa por referencia

            while (inicar_servidor)
            {
                try
                {
                    //Bloqueo hasta recibir mensaje de clientes
                    var mesage = reader.ReadLine();
                    //Deserialización del objeto recibido por medio de json
                    Sockets<object> recibir = JsonConvert.DeserializeObject<Sockets<object>>(mesage);
                    Select_Op(recibir.Metod, mesage, ref servidorStreamWriter);
                }
                catch (Exception e)
                {
                    //Mensaje de error 
                    MessageBox.Show("Ha cerrado La aplicación");
                    break;
                }
            }

            TC_cliente.Close();
        }

        /// <param name="message">Nombre del método que se debe invocar</param>
        /// <param name="option">Mensaje enviado por el cliente</param>
        public void Select_Op(string option, string message, ref StreamWriter servidor_StreamWriter)
        {
            switch (option)
            {
                case "Conexion":
                    Sockets<string> mensajeConectar = JsonConvert.DeserializeObject<Sockets<string>>(message);// Se deserializa el objeto recibido mediante json
                    Conectar(mensajeConectar.Entity);
                    break;

                case "desconect":
                    Sockets<string> mensajeDesconectar = JsonConvert.DeserializeObject<Sockets<string>>(message);//Se deserializa el objeto recibido mediante json
                    Desconect(mensajeDesconectar.Entity);
                    break;
                case "Vendedor_Existe":
                    Sockets<string> mensajeVerificarVendedor = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    Vendedor_existe_Ventana(mensajeVerificarVendedor.Entity, ref servidor_StreamWriter);
                    break;
                case "Vendedor_Datos":
                    Sockets<string> mensajeDatos_Vendedor = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    Vendedor_Datos_Ventana(mensajeDatos_Vendedor.Entity, ref servidor_StreamWriter);
                    break;
                case "Obtener_Datos_Articulos":
                    Sockets<string> mensajeDatos_Articulo = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    Obtener_articulos_Ventana(ref servidor_StreamWriter);
                    break;
                case "Obtener_Mayor_Ordencompra":
                    Sockets<string> mensaje_OrdenCompra_Mayor = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    Obtener_Mayor_Ordencompra_Ventana(ref servidor_StreamWriter);
                    break;
                case "Obtener_Mayor_Ordencompra_V":
                    Sockets<string> mensaje_OrdenCompra_Mayor_V = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    Obtener_Mayor_Ordencompra_Vend_Ventana(mensaje_OrdenCompra_Mayor_V.Entity, ref servidor_StreamWriter);
                    break;
                case "Obtener_Mayor_OrdencompraDetalle":
                    Sockets<string> mensaje_OrdenCompraDetalle_Mayor = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    Obtener_Mayor_OrdencompraDetalle_Ventana(ref servidor_StreamWriter);
                    break;
                case "Insertar_Ordencompra":
                    Sockets<OrdenCompra> mensaje_Insertar_Ordencompra = JsonConvert.DeserializeObject<Sockets<OrdenCompra>>(message);//deserializa  json
                    Insertar_Ordencompra_Ventana(mensaje_Insertar_Ordencompra.Entity);
                    break;
                case "Insertar_DetalleOrdencompra":
                    Sockets<List<OrdenCompraDetalle>> mensaje_Insertar_DetalleOrdencompra = JsonConvert.DeserializeObject<Sockets<List<OrdenCompraDetalle>>>(message);//deserializa  json
                    Insertar_DetalleOrdencompra_Ventana(mensaje_Insertar_DetalleOrdencompra.Entity);
                    break;
                case "Actualizar_Inventario":
                    Sockets<List<Articulo>> mensaje_Actualizar_Inventario = JsonConvert.DeserializeObject<Sockets<List<Articulo>>>(message);//deserializa  json
                    Actualizar_Inventario_Ventana(mensaje_Actualizar_Inventario.Entity);
                    break;
                case "Obtener_datos_Ordencompra_V":
                    Sockets<string> mensaje_OrdenCompra_V = JsonConvert.DeserializeObject<Sockets<string>>(message);//deserializa  json
                    obtener_datos_ordencompra_vend_Ventana(mensaje_OrdenCompra_V.Entity, ref servidor_StreamWriter);
                    break;
                case "Obtener_datos_Ordencompra":
                    Sockets<int> mensaje_OrdenCompra = JsonConvert.DeserializeObject<Sockets<int>>(message);//deserializa  json
                    obtener_datos_ordencompra_Ventana(mensaje_OrdenCompra.Entity, ref servidor_StreamWriter);
                    break;
                case "Obtener_datos_OrdencompraDet_V":
                    Sockets<int> mensaje_OrdenCompraDet = JsonConvert.DeserializeObject<Sockets<int>>(message);//deserializa  json
                    obtener_datos_ordencompraDet_Ventana(mensaje_OrdenCompraDet.Entity, ref servidor_StreamWriter);
                    break;
                default:
                    break;
            }
        }
        
        private void client_listener()
        {
            tcpListener.Start();
            while (inicar_servidor)
            {
                try
                {
                    //Se bloquea hasta que un cliente se haya conectado al servidor 
                    TcpClient client = tcpListener.AcceptTcpClient();
                    /*Se crea un nuevo hilo para manejar la comunicación con los clientes que se conectan al servidor*/
                    Thread clientThread = new Thread(new ParameterizedThreadStart(intercomunicacion_client));
                    clientThread.Start(client);

                }

                catch (Exception E)
                {
                    MessageBox.Show(" Se ha detenido el servidor");
                    return;
                }
                
            }
        }

        private void Conectar(string IDCliente)
        {

            if (this.InvokeRequired) // Se verifica que la información esté en el mismo hilo.
            {
                this.Invoke(new clientes_ventana_Delegado(Conectar), IDCliente);// Si están en distintos hilos, se invoca el
            }                                                                  // al este hilo
            else
            {

                richTextBox_conectados.AppendText("Se ha conectado " + IDCliente + "\n");
            }
        }
        private void Desconect(string IDCliente)
        {

            if (this.InvokeRequired) // Se verifica que la información esté en el mismo hilo.
            {
                this.Invoke(new clientes_ventana_Delegado(Desconect), IDCliente);// Si están en distintos hilos, se invoca el
            }                                                                  // al este hilo
            else
            {
                richTextBox_conectados.AppendText("Se ha desconectado " + IDCliente + "\n");
            }
        }


        public void Vendedor_existe_Ventana(string IDVendedor, ref StreamWriter server_StreamWriter)
         {
            bool existe;
            existe = Vendedor_existe_Negocio(IDVendedor);
             
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(existe));
            server_StreamWriter.Flush();
        }

        public void Vendedor_Datos_Ventana(string IDVendedor, ref StreamWriter server_StreamWriter)
        {
            Vendedor vendedor_D;
            vendedor_D = obtener_datos_un_vendedor_Negocio(IDVendedor);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(vendedor_D));
            server_StreamWriter.Flush();

        }
        public void Obtener_articulos_Ventana(ref StreamWriter server_StreamWriter)
        {
            List<Articulo> lista_A= new List<Articulo>();
            lista_A = obtener_datos_articulos_Negocio();
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(lista_A));
            server_StreamWriter.Flush();
        }

        public void Obtener_Mayor_Ordencompra_Ventana(ref StreamWriter server_StreamWriter)
        {
            int Mayor_OrdenCompra = obtener_mayor_ordencompra_Megocio();
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(Mayor_OrdenCompra));
            server_StreamWriter.Flush();
        }
        public void Obtener_Mayor_Ordencompra_Vend_Ventana(string IDVendedor, ref StreamWriter server_StreamWriter)
        {
            int Mayor_OrdenCompra = obtener_mayor_ordencompra_x_vendedor_Negocio(IDVendedor);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(Mayor_OrdenCompra));
            server_StreamWriter.Flush();
        }

        public void obtener_datos_ordencompra_vend_Ventana(string IDVendedor, ref StreamWriter server_StreamWriter)
        {
            List<OrdenCompra> lista_ordenes = new List<OrdenCompra>();
            lista_ordenes = obtener_datos_ordencompra_x_vendedor_Negocio(IDVendedor);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(lista_ordenes));
            server_StreamWriter.Flush();
        }

        public void Obtener_Mayor_OrdencompraDetalle_Ventana(ref StreamWriter server_StreamWriter)
        {
            int Mayor_OrdenCompraDetalle = obtener_mayor_detalle_Megocio();
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(Mayor_OrdenCompraDetalle));
            server_StreamWriter.Flush();
        }

        private void ImprimirOrden(string IDCompra)
        {

            if (this.InvokeRequired) // Se verifica que la información esté en el mismo hilo.
            {
                this.Invoke(new clientes_ventana_Delegado(ImprimirOrden), IDCompra);// Si están en distintos hilos, se invoca el
            }                                                                  // al este hilo
            else
            {
                richTextBox_conectados.AppendText("Se ha generado la orden de compra " + IDCompra + "\n");
            }
        }

        public void Insertar_Ordencompra_Ventana(OrdenCompra la_compris)
        {
            ordencompra_insertar_Negocio(la_compris);

            if (this.InvokeRequired) // Se verifica que la información esté en el mismo hilo.
            {
                this.Invoke(new clientes_ventana_Delegado(ImprimirOrden), la_compris.Id_Compra.ToString());// Si están en distintos hilos, se invoca el
            }                                                                  // al este hilo
            else
            {
                richTextBox_conectados.AppendText("Se ha generado la orden de compra " + la_compris.Id_Compra.ToString() + "\n");
            }
        }

        public void Insertar_DetalleOrdencompra_Ventana(List<OrdenCompraDetalle> la_listadelascompris)
        {
            detalle_ordencompra_insertar_Negocio(la_listadelascompris);
        }

        public void Actualizar_Inventario_Ventana(List<Articulo> lista_A)
        {
            actualizar_inventario_Negocio(lista_A);
        }

        public void obtener_datos_ordencompra_Ventana(int IDCompra, ref StreamWriter server_StreamWriter)
        {
            OrdenCompra OrdenC;
            OrdenC = obtener_datos_una_ordencompra_Negocio(IDCompra);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(OrdenC));
            server_StreamWriter.Flush();
        }

        public void obtener_datos_ordencompraDet_Ventana(int IDCompra, ref StreamWriter server_StreamWriter)
        {
            List<OrdenCompraDetalle> Lista_detalle = new List<OrdenCompraDetalle>();
            Lista_detalle = obtener_datos_detalleordencompra_Negocio(IDCompra);
            server_StreamWriter.WriteLine(JsonConvert.SerializeObject(Lista_detalle));
            server_StreamWriter.Flush();
        }
        //-----------------------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------
        private void btnreg_art_Click_1(object sender, EventArgs e)
         {
             Abrir_ventanas(new Regristro_articulos());
         }

         private void btnservidor_Click_1(object sender, EventArgs e)
         {

             Abrir_ventanas(new Información_Servidor());
         }

        private void richTextBox(string texto, bool agregar)
        {
            if (agregar)
            {
                richTextBox_conectados.Text = texto;
            }
            else
            {
                richTextBox_conectados.Text = "";
            }

        }

        private void btniniciar_Click_1(object sender, EventArgs e)
         {

            panelcentral.Visible = true;
            IPAddress local = IPAddress.Parse("127.0.0.1");
             tcpListener = new TcpListener(local, 16830);
             inicar_servidor = true;

             subprocesolisten = new Thread(new ThreadStart(client_listener));
             subprocesolisten.Start();
             subprocesolisten.IsBackground = true;
             txtestado.Text = "Escuchando clientes... en (127.0.0.1, 30000)";
             txtestado.ForeColor = Color.Green;
             btniniciar.Enabled = false;
             btndetener.Enabled = true;
           // txtBitacora.Invoke(modificarTextotxtBitacora, new object[] { pIdentificadorCliente + " se ha conectado..." });
           // richTextBox_conectados.Invoke(richTextBox, new object[] { IDVendedor, true });


        }

        private void btndetener_Click(object sender, EventArgs e)
         {
            
                inicar_servidor = false;
                tcpListener.Stop();
                subprocesolisten.Abort();
                txtestado.ForeColor = Color.Red;
                txtestado.Text = "No iniciado";
                btniniciar.Enabled = true;
                btndetener.Enabled = false;
     
         }

         private void btn_consultar_inventario_Click_1(object sender, EventArgs e)
         {
             Abrir_ventanas(new Consulta_Inventario());
         }

         private void btn_actualizar_inventario_Click(object sender, EventArgs e)
         {
             Abrir_ventanas(new Actualizar_inventario());
         }

         private void btnsalir_Click_1(object sender, EventArgs e)
         {
             var resultado = MessageBox.Show("¿Desea salir de la aplicación?", "Agregar", MessageBoxButtons.YesNo,
        MessageBoxIcon.Question);
             if (resultado == DialogResult.No)
             {
                 return;
             }
             else
             {
                 Application.Exit();
             }
         }

         private void btncerrar_Click(object sender, EventArgs e)
         {
             Application.Exit();
         }

         private void btnreg_vendedores_Click(object sender, EventArgs e)
         {
             Abrir_ventanas(new Registro_Vendedores());
         }

        private void panelcentral_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_consultarventas_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Consulta_Ventas());
        }

        private void Inicio_Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }
    }

}