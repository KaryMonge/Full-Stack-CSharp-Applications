﻿namespace Ventanas
{
    partial class Inicio_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio_Menu));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncerrar = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.richTextBox_conectados = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btndetener = new System.Windows.Forms.Button();
            this.txtestado = new System.Windows.Forms.TextBox();
            this.btniniciar = new System.Windows.Forms.Button();
            this.panelmenu = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.btn_consultarventas = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btn_consultar_inventario = new System.Windows.Forms.Button();
            this.btnsalir = new System.Windows.Forms.Button();
            this.btnreg_art = new System.Windows.Forms.Button();
            this.btnreg_vendedores = new System.Windows.Forms.Button();
            this.btn_actualizar_inventario = new System.Windows.Forms.Button();
            this.panelcentral = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).BeginInit();
            this.panelmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btncerrar);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1184, 48);
            this.panel1.TabIndex = 3;
            // 
            // btncerrar
            // 
            this.btncerrar.Image = ((System.Drawing.Image)(resources.GetObject("btncerrar.Image")));
            this.btncerrar.Location = new System.Drawing.Point(1143, 4);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(34, 32);
            this.btncerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btncerrar.TabIndex = 2;
            this.btncerrar.TabStop = false;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(585, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "EMPRESA FARO S.A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label3.Location = new System.Drawing.Point(62, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "MENÚ INICIAL";
            // 
            // richTextBox_conectados
            // 
            this.richTextBox_conectados.BackColor = System.Drawing.SystemColors.MenuText;
            this.richTextBox_conectados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.richTextBox_conectados.Location = new System.Drawing.Point(3, 142);
            this.richTextBox_conectados.Name = "richTextBox_conectados";
            this.richTextBox_conectados.ReadOnly = true;
            this.richTextBox_conectados.Size = new System.Drawing.Size(314, 134);
            this.richTextBox_conectados.TabIndex = 39;
            this.richTextBox_conectados.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(7, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(204, 21);
            this.label2.TabIndex = 38;
            this.label2.Text = "Clientes Conectados :";
            // 
            // btndetener
            // 
            this.btndetener.BackColor = System.Drawing.Color.Black;
            this.btndetener.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btndetener.FlatAppearance.BorderSize = 3;
            this.btndetener.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.btndetener.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btndetener.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndetener.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btndetener.Location = new System.Drawing.Point(210, 44);
            this.btndetener.Name = "btndetener";
            this.btndetener.Size = new System.Drawing.Size(87, 31);
            this.btndetener.TabIndex = 36;
            this.btndetener.Text = "Off";
            this.btndetener.UseVisualStyleBackColor = false;
            this.btndetener.Click += new System.EventHandler(this.btndetener_Click);
            // 
            // txtestado
            // 
            this.txtestado.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtestado.Location = new System.Drawing.Point(7, 81);
            this.txtestado.Name = "txtestado";
            this.txtestado.ReadOnly = true;
            this.txtestado.Size = new System.Drawing.Size(290, 20);
            this.txtestado.TabIndex = 41;
            // 
            // btniniciar
            // 
            this.btniniciar.BackColor = System.Drawing.Color.Black;
            this.btniniciar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btniniciar.FlatAppearance.BorderSize = 3;
            this.btniniciar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MidnightBlue;
            this.btniniciar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btniniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btniniciar.ForeColor = System.Drawing.Color.Green;
            this.btniniciar.Location = new System.Drawing.Point(7, 44);
            this.btniniciar.Name = "btniniciar";
            this.btniniciar.Size = new System.Drawing.Size(92, 31);
            this.btniniciar.TabIndex = 35;
            this.btniniciar.Text = "ON";
            this.btniniciar.UseVisualStyleBackColor = false;
            this.btniniciar.Click += new System.EventHandler(this.btniniciar_Click_1);
            // 
            // panelmenu
            // 
            this.panelmenu.BackColor = System.Drawing.SystemColors.ControlText;
            this.panelmenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelmenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelmenu.Controls.Add(this.pictureBox5);
            this.panelmenu.Controls.Add(this.pictureBox6);
            this.panelmenu.Controls.Add(this.btn_consultarventas);
            this.panelmenu.Controls.Add(this.label4);
            this.panelmenu.Controls.Add(this.pictureBox4);
            this.panelmenu.Controls.Add(this.pictureBox2);
            this.panelmenu.Controls.Add(this.pictureBox1);
            this.panelmenu.Controls.Add(this.pictureBox3);
            this.panelmenu.Controls.Add(this.btn_consultar_inventario);
            this.panelmenu.Controls.Add(this.btnsalir);
            this.panelmenu.Controls.Add(this.btnreg_art);
            this.panelmenu.Controls.Add(this.btnreg_vendedores);
            this.panelmenu.Controls.Add(this.btn_actualizar_inventario);
            this.panelmenu.Controls.Add(this.btniniciar);
            this.panelmenu.Controls.Add(this.txtestado);
            this.panelmenu.Controls.Add(this.btndetener);
            this.panelmenu.Controls.Add(this.label2);
            this.panelmenu.Controls.Add(this.richTextBox_conectados);
            this.panelmenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelmenu.Location = new System.Drawing.Point(0, 48);
            this.panelmenu.Name = "panelmenu";
            this.panelmenu.Size = new System.Drawing.Size(325, 563);
            this.panelmenu.TabIndex = 6;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(197, 516);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(42, 33);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 51;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(255, 458);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(42, 34);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 50;
            this.pictureBox6.TabStop = false;
            // 
            // btn_consultarventas
            // 
            this.btn_consultarventas.BackColor = System.Drawing.Color.DimGray;
            this.btn_consultarventas.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_consultarventas.FlatAppearance.BorderSize = 3;
            this.btn_consultarventas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_consultarventas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn_consultarventas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_consultarventas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_consultarventas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_consultarventas.Location = new System.Drawing.Point(43, 458);
            this.btn_consultarventas.Name = "btn_consultarventas";
            this.btn_consultarventas.Size = new System.Drawing.Size(206, 34);
            this.btn_consultarventas.TabIndex = 49;
            this.btn_consultarventas.Text = "Consultar Ventas";
            this.btn_consultarventas.UseVisualStyleBackColor = false;
            this.btn_consultarventas.Click += new System.EventHandler(this.btn_consultarventas_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(7, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(232, 24);
            this.label4.TabIndex = 47;
            this.label4.Text = "Conectar a Servidor";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(255, 418);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(42, 34);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 46;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(255, 370);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(42, 34);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(255, 322);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(42, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(255, 282);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(42, 34);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 43;
            this.pictureBox3.TabStop = false;
            // 
            // btn_consultar_inventario
            // 
            this.btn_consultar_inventario.BackColor = System.Drawing.Color.DimGray;
            this.btn_consultar_inventario.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_consultar_inventario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_consultar_inventario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_consultar_inventario.Location = new System.Drawing.Point(43, 322);
            this.btn_consultar_inventario.Name = "btn_consultar_inventario";
            this.btn_consultar_inventario.Size = new System.Drawing.Size(206, 34);
            this.btn_consultar_inventario.TabIndex = 6;
            this.btn_consultar_inventario.Text = "Consultar Inventario";
            this.btn_consultar_inventario.UseVisualStyleBackColor = false;
            this.btn_consultar_inventario.Click += new System.EventHandler(this.btn_consultar_inventario_Click_1);
            // 
            // btnsalir
            // 
            this.btnsalir.BackColor = System.Drawing.Color.DimGray;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsalir.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsalir.Location = new System.Drawing.Point(43, 516);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(157, 33);
            this.btnsalir.TabIndex = 0;
            this.btnsalir.Text = "SALIR";
            this.btnsalir.UseVisualStyleBackColor = false;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click_1);
            // 
            // btnreg_art
            // 
            this.btnreg_art.BackColor = System.Drawing.Color.DimGray;
            this.btnreg_art.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnreg_art.FlatAppearance.BorderSize = 2;
            this.btnreg_art.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkBlue;
            this.btnreg_art.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnreg_art.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreg_art.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnreg_art.Location = new System.Drawing.Point(43, 284);
            this.btnreg_art.Name = "btnreg_art";
            this.btnreg_art.Size = new System.Drawing.Size(206, 32);
            this.btnreg_art.TabIndex = 1;
            this.btnreg_art.Text = "Registrar Artículos";
            this.btnreg_art.UseVisualStyleBackColor = false;
            this.btnreg_art.Click += new System.EventHandler(this.btnreg_art_Click_1);
            // 
            // btnreg_vendedores
            // 
            this.btnreg_vendedores.BackColor = System.Drawing.Color.DimGray;
            this.btnreg_vendedores.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnreg_vendedores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreg_vendedores.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnreg_vendedores.Location = new System.Drawing.Point(43, 370);
            this.btnreg_vendedores.Name = "btnreg_vendedores";
            this.btnreg_vendedores.Size = new System.Drawing.Size(204, 34);
            this.btnreg_vendedores.TabIndex = 2;
            this.btnreg_vendedores.Text = "Registrar Vendedores";
            this.btnreg_vendedores.UseVisualStyleBackColor = false;
            this.btnreg_vendedores.Click += new System.EventHandler(this.btnreg_vendedores_Click);
            // 
            // btn_actualizar_inventario
            // 
            this.btn_actualizar_inventario.BackColor = System.Drawing.Color.DimGray;
            this.btn_actualizar_inventario.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_actualizar_inventario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_actualizar_inventario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_actualizar_inventario.Location = new System.Drawing.Point(43, 418);
            this.btn_actualizar_inventario.Name = "btn_actualizar_inventario";
            this.btn_actualizar_inventario.Size = new System.Drawing.Size(206, 34);
            this.btn_actualizar_inventario.TabIndex = 5;
            this.btn_actualizar_inventario.Text = "Actualizar Inventario";
            this.btn_actualizar_inventario.UseVisualStyleBackColor = false;
            this.btn_actualizar_inventario.Click += new System.EventHandler(this.btn_actualizar_inventario_Click);
            // 
            // panelcentral
            // 
            this.panelcentral.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelcentral.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelcentral.BackgroundImage")));
            this.panelcentral.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelcentral.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelcentral.Location = new System.Drawing.Point(325, 48);
            this.panelcentral.Name = "panelcentral";
            this.panelcentral.Size = new System.Drawing.Size(859, 563);
            this.panelcentral.TabIndex = 7;
            this.panelcentral.Paint += new System.Windows.Forms.PaintEventHandler(this.panelcentral_Paint);
            // 
            // Inicio_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 611);
            this.Controls.Add(this.panelcentral);
            this.Controls.Add(this.panelmenu);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Inicio_Menu";
            this.Text = "Inicio_Menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Inicio_Menu_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).EndInit();
            this.panelmenu.ResumeLayout(false);
            this.panelmenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox btncerrar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox richTextBox_conectados;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btndetener;
        private System.Windows.Forms.TextBox txtestado;
        private System.Windows.Forms.Button btniniciar;
        private System.Windows.Forms.Panel panelmenu;
        private System.Windows.Forms.Button btn_consultar_inventario;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.Button btnreg_art;
        private System.Windows.Forms.Button btnreg_vendedores;
        private System.Windows.Forms.Button btn_actualizar_inventario;
        private System.Windows.Forms.Panel panelcentral;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btn_consultarventas;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}