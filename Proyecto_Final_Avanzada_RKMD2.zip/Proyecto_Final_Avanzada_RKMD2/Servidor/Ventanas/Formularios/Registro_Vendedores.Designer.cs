﻿
namespace Ventanas.Sub_menu
{
    partial class Registro_Vendedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro_Vendedores));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFecha_ingreso = new System.Windows.Forms.TextBox();
            this.btnregistrar = new System.Windows.Forms.Button();
            this.txt_2Apell = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_1Apell = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtid_vendedor = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox_genero = new System.Windows.Forms.GroupBox();
            this.radioButtonotro = new System.Windows.Forms.RadioButton();
            this.radioButtonM = new System.Windows.Forms.RadioButton();
            this.radioButtonF = new System.Windows.Forms.RadioButton();
            this.dateTimePicker_Nacimineto = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox_genero.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(208, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(365, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "REGISTRO DE VENDEDORES";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(219, 424);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 24);
            this.label3.TabIndex = 21;
            this.label3.Text = "Género";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlText;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(214, 194);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "Céd Vendedor";
            // 
            // txtFecha_ingreso
            // 
            this.txtFecha_ingreso.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txtFecha_ingreso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFecha_ingreso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtFecha_ingreso.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtFecha_ingreso.Location = new System.Drawing.Point(473, 480);
            this.txtFecha_ingreso.Name = "txtFecha_ingreso";
            this.txtFecha_ingreso.Size = new System.Drawing.Size(228, 26);
            this.txtFecha_ingreso.TabIndex = 18;
            // 
            // btnregistrar
            // 
            this.btnregistrar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnregistrar.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnregistrar.FlatAppearance.BorderSize = 2;
            this.btnregistrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnregistrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Navy;
            this.btnregistrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnregistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnregistrar.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnregistrar.Location = new System.Drawing.Point(364, 523);
            this.btnregistrar.Name = "btnregistrar";
            this.btnregistrar.Size = new System.Drawing.Size(150, 37);
            this.btnregistrar.TabIndex = 12;
            this.btnregistrar.Text = "Registrar";
            this.btnregistrar.UseVisualStyleBackColor = false;
            this.btnregistrar.Click += new System.EventHandler(this.btnregistrar_Click);
            // 
            // txt_2Apell
            // 
            this.txt_2Apell.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_2Apell.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_2Apell.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txt_2Apell.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txt_2Apell.Location = new System.Drawing.Point(473, 332);
            this.txt_2Apell.Name = "txt_2Apell";
            this.txt_2Apell.Size = new System.Drawing.Size(228, 26);
            this.txt_2Apell.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Location = new System.Drawing.Point(219, 479);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 24);
            this.label5.TabIndex = 9;
            this.label5.Text = "Fecha Ingreso";
            // 
            // txt_1Apell
            // 
            this.txt_1Apell.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_1Apell.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_1Apell.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txt_1Apell.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txt_1Apell.Location = new System.Drawing.Point(473, 284);
            this.txt_1Apell.Name = "txt_1Apell";
            this.txt_1Apell.Size = new System.Drawing.Size(228, 26);
            this.txt_1Apell.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Location = new System.Drawing.Point(214, 378);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 24);
            this.label6.TabIndex = 10;
            this.label6.Text = "Fecha Nac";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(214, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nombre";
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_Nombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txt_Nombre.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txt_Nombre.Location = new System.Drawing.Point(473, 237);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.Size = new System.Drawing.Size(228, 26);
            this.txt_Nombre.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Location = new System.Drawing.Point(214, 331);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 24);
            this.label7.TabIndex = 11;
            this.label7.Text = "2do Apellido";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Location = new System.Drawing.Point(214, 286);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "1er Apellido";
            // 
            // txtid_vendedor
            // 
            this.txtid_vendedor.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txtid_vendedor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtid_vendedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtid_vendedor.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtid_vendedor.Location = new System.Drawing.Point(473, 192);
            this.txtid_vendedor.Name = "txtid_vendedor";
            this.txtid_vendedor.Size = new System.Drawing.Size(228, 26);
            this.txtid_vendedor.TabIndex = 25;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(859, 124);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox_genero
            // 
            this.groupBox_genero.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.groupBox_genero.Controls.Add(this.radioButtonotro);
            this.groupBox_genero.Controls.Add(this.radioButtonM);
            this.groupBox_genero.Controls.Add(this.radioButtonF);
            this.groupBox_genero.Location = new System.Drawing.Point(473, 424);
            this.groupBox_genero.Name = "groupBox_genero";
            this.groupBox_genero.Size = new System.Drawing.Size(228, 33);
            this.groupBox_genero.TabIndex = 29;
            this.groupBox_genero.TabStop = false;
            // 
            // radioButtonotro
            // 
            this.radioButtonotro.AutoSize = true;
            this.radioButtonotro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonotro.Location = new System.Drawing.Point(160, 9);
            this.radioButtonotro.Name = "radioButtonotro";
            this.radioButtonotro.Size = new System.Drawing.Size(53, 22);
            this.radioButtonotro.TabIndex = 31;
            this.radioButtonotro.Text = "N/A";
            this.radioButtonotro.UseVisualStyleBackColor = true;
            // 
            // radioButtonM
            // 
            this.radioButtonM.AutoSize = true;
            this.radioButtonM.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonM.Location = new System.Drawing.Point(86, 8);
            this.radioButtonM.Name = "radioButtonM";
            this.radioButtonM.Size = new System.Drawing.Size(40, 22);
            this.radioButtonM.TabIndex = 30;
            this.radioButtonM.Text = "M";
            this.radioButtonM.UseVisualStyleBackColor = true;
            // 
            // radioButtonF
            // 
            this.radioButtonF.AutoSize = true;
            this.radioButtonF.Checked = true;
            this.radioButtonF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonF.Location = new System.Drawing.Point(6, 8);
            this.radioButtonF.Name = "radioButtonF";
            this.radioButtonF.Size = new System.Drawing.Size(35, 20);
            this.radioButtonF.TabIndex = 0;
            this.radioButtonF.TabStop = true;
            this.radioButtonF.Text = "F";
            this.radioButtonF.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker_Nacimineto
            // 
            this.dateTimePicker_Nacimineto.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_Nacimineto.CalendarMonthBackground = System.Drawing.SystemColors.InactiveCaption;
            this.dateTimePicker_Nacimineto.Font = new System.Drawing.Font("Times New Roman", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_Nacimineto.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_Nacimineto.Location = new System.Drawing.Point(473, 378);
            this.dateTimePicker_Nacimineto.MaxDate = new System.DateTime(2003, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker_Nacimineto.MinDate = new System.DateTime(1921, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker_Nacimineto.Name = "dateTimePicker_Nacimineto";
            this.dateTimePicker_Nacimineto.Size = new System.Drawing.Size(228, 25);
            this.dateTimePicker_Nacimineto.TabIndex = 30;
            this.dateTimePicker_Nacimineto.Value = new System.DateTime(2003, 1, 1, 0, 0, 0, 0);
            // 
            // Registro_Vendedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(859, 563);
            this.Controls.Add(this.dateTimePicker_Nacimineto);
            this.Controls.Add(this.groupBox_genero);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtid_vendedor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_2Apell);
            this.Controls.Add(this.txt_Nombre);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_1Apell);
            this.Controls.Add(this.btnregistrar);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtFecha_ingreso);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Registro_Vendedores";
            this.Text = "Registro_Vendedores";
            this.Load += new System.EventHandler(this.Registro_Vendedores_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox_genero.ResumeLayout(false);
            this.groupBox_genero.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFecha_ingreso;
        private System.Windows.Forms.Button btnregistrar;
        private System.Windows.Forms.TextBox txt_2Apell;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_1Apell;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtid_vendedor;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox_genero;
        private System.Windows.Forms.RadioButton radioButtonotro;
        private System.Windows.Forms.RadioButton radioButtonM;
        private System.Windows.Forms.RadioButton radioButtonF;
        private System.Windows.Forms.DateTimePicker dateTimePicker_Nacimineto;
    }
}