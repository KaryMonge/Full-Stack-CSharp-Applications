﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Negocios.Utilidades.Extend_Bd;
using static Entidades.Clases.Articulo;
using static Entidades.Clases.OrdenCompra;
using Entidades.Clases;


namespace Ventanas.Sub_menu
{
    public partial class Consulta_Ventas : Form
    {
        public Consulta_Ventas()
        {
            InitializeComponent();

            int contador_compras = obtener_mayor_ordencompra_Megocio();

            if (contador_compras == 0)

            {
                MessageBox.Show("No existen Compras, no se puede realizar la Consulta");
                return;
            }
            else
            {

                //Llenado de ordenes de compra
                List<OrdenCompra> lista_ordenes = new List<OrdenCompra>();
                lista_ordenes = obtener_datos_ordencompra_Negocio();

                //Llenado del combobox con los vendedores que vienen en la lista
                foreach (OrdenCompra orden_leida in lista_ordenes)
                {
                    comboBoxid_compra.Items.Add(orden_leida.Id_Compra);
                }
            }

        }

        int id_compra =0;
              
        private void comboBoxid_compra_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal precio_total_vendedor = 0;
            decimal precio_total_final = 0;

            dataGrid_Consultar_ventas.DataSource = null;
            dataGrid_Consultar_ventas.Rows.Clear();
            id_compra = int.Parse(comboBoxid_compra.Text);
            OrdenCompra comprita = new OrdenCompra();

            comprita = obtener_datos_una_ordencompra_Negocio(id_compra);

            txtfechacompra.Text = comprita.Fecha.ToShortDateString();
            txtidvend.Text = comprita.Vendedor;
            txtnombre.Text = comprita.Nombre_Vend;
            txt1apell.Text = comprita.Prim_Apell;
            txt2apell.Text = comprita.Seg_Apell;

            List<OrdenCompraDetalle> lista_detalle = new List<OrdenCompraDetalle>();
            lista_detalle = obtener_datos_detalleordencompra_Negocio(id_compra);

            //Llenado del combobox con los vendedores que vienen en la lista
            foreach (OrdenCompraDetalle detalleorden_leida in lista_detalle)
            {
                dataGrid_Consultar_ventas.Rows.Add(detalleorden_leida.IdDetalle, detalleorden_leida.Id_Articulo, detalleorden_leida.Descripcion, detalleorden_leida.Cantidad, detalleorden_leida.Precio_Vend, detalleorden_leida.Precio_Final);
                precio_total_vendedor = precio_total_vendedor + detalleorden_leida.Precio_Vend;
                precio_total_final = precio_total_final + detalleorden_leida.Precio_Final;
            }
            txtvprevendetotal.Text = precio_total_vendedor.ToString();
            txtprefinaltot.Text = precio_total_final.ToString();
        }
    }
}
