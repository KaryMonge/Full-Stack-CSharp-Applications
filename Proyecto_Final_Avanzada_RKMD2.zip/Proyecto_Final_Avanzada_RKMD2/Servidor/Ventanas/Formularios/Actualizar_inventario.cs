﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clases;

using static Negocios.Utilidades.Extend_Bd;

namespace Ventanas.Sub_menu
{
    public partial class Actualizar_inventario : Form
    {
        public Actualizar_inventario()
        {
            InitializeComponent();

            int contador_articulos = 0;

            List<Articulo> lista_desgloce = new List<Articulo>();

            lista_desgloce = obtener_datostotales_articulos_Negocio();

            foreach (Articulo cosita in lista_desgloce)
            {
                comboBox_id_iarticulos.Items.Add(cosita.Id_Articulo);
                string Activo;
                if (cosita.Activo)
                {
                    Activo = "Sí";
                }
                else
                {
                    Activo = "No";
                }
                dataGrid_Lista_Articulos.Rows.Add(cosita.Id_Articulo, cosita.Cantidad_Disponible, cosita.Descripcion, Activo, cosita.Precio_Vend, cosita.Precio_Final);
                contador_articulos++;
            }

            if (contador_articulos == 0)
            {
                MessageBox.Show("La lista de artículos está vacía");
                return;
            }
 
        }
        
        private void btnactualizar_Click(object sender, EventArgs e)
        {
            //aquí se actualizan los datillos chi sheñol
            bool activ = false;

            if (comboBox_id_iarticulos.Text == null || comboBox_id_iarticulos.Text == "")
            {
                MessageBox.Show("Debe seleccionar un Id artículo","ERROR");
                return;
            }

            try
            {
                if (radioButtonSI.Checked == true)
                {
                    activ = true;
                }
                else if (radioButtonNO.Checked == true)
                {
                    activ = false;
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un tipo de ACTIVO");
                }


                if (int.Parse(txtnuevacantidad.Text) < 0 || decimal.Parse(txtpreciovend.Text) < 0 || decimal.Parse(txtpreciofin.Text) < 0)    
                {
                    MessageBox.Show("No se permiten números negativos");
                    txtnuevacantidad.Text = string.Empty;
                    return;
                }

            }
            catch(FormatException)
            {
                MessageBox.Show("Digite los campos correctamente");

                txtnuevacantidad.Text = string.Empty;
                txtpreciofin.Text = string.Empty;
                txtpreciovend.Text = string.Empty;
                return;
            }

            actualizar_articulos_update_Negocio(int.Parse(comboBox_id_iarticulos.Text), activ, decimal.Parse(txtpreciovend.Text), decimal.Parse(txtpreciofin.Text), int.Parse(txtnuevacantidad.Text));

            //Se limpia el inventario porque hubo cambios
            dataGrid_Lista_Articulos.DataSource = null;
            dataGrid_Lista_Articulos.Rows.Clear();
            
            //Se vuelve a llenar el data con los artículos y se repite el código
            //(y no se encapsula falta de tiempo)
            List<Articulo> lista_desgloce = new List<Articulo>();

            lista_desgloce = obtener_datostotales_articulos_Negocio();

            foreach (Articulo cosita in lista_desgloce)
            {
                comboBox_id_iarticulos.Items.Add(cosita.Id_Articulo);
                string Activo;
                if (cosita.Activo)
                {
                    Activo = "Sí";
                }
                else
                {
                    Activo = "No";
                }
                dataGrid_Lista_Articulos.Rows.Add(cosita.Id_Articulo, cosita.Cantidad_Disponible, cosita.Descripcion, Activo, cosita.Precio_Vend, cosita.Precio_Final);
            }
            txtpreciovend.Clear();
            comboBox_id_iarticulos.SelectedIndex = -1;
            txtnuevacantidad.Clear();
            txtpreciofin.Clear();
        }
    }
}
