﻿using System;
using Ventanas.Sub_menu;

namespace Ventanas
{
    internal class Regristro_Vendedores
    {
     
    }
}