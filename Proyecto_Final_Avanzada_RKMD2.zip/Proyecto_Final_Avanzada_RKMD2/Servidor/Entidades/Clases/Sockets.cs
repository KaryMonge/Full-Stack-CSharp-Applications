﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clases
{

    //clase para el manejo de envío de mensajes servidor/cliente hiloshhh 
    /// <typeparam name="E"></typeparam>   
    public class Sockets<E>
    {
        //  El método que debe ejecutarse en el servidor
        public string Metod { get; set; }


        //Enví la entidad que se debe procesar en el método solicitado por el cliente
        /// para cualquier entidad, debe indicarse al momento de ser instanciada.
        public E Entity { get; set; }
    }

    




}
