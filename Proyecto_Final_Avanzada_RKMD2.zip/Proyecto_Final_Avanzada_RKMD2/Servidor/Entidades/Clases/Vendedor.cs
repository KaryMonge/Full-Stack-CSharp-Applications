﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clases
{
    public class Vendedor
    {
        public  string Ident_Vend { get; set; }
        public  string Nombre_Vend { get; set; }

        public  string  Prim_Apell {get; set;}

        public  string Seg_Apell {get; set;}

        public  DateTime Fecha_Nac { get; set; }

        public  Char Genero { get; set; }

        public  DateTime Fecha_ing { get; set; }

        public  Vendedor()
        {
            Ident_Vend = string.Empty;
            Nombre_Vend = string.Empty;
            Prim_Apell = string.Empty;
            Seg_Apell = string.Empty;
            Fecha_Nac = DateTime.MinValue;
            Genero = '\0';
            Fecha_ing = DateTime.Today;

        }
    }
}
