﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ventanas.Formularios;
using System.Windows.Forms;
using Entidades.Clases;


namespace Ventanas
{
   
    public partial class menu_inicial : Form
    {
        bool conexion_cliente_vendedor = false;
        public static string IDVendedor = "";
        public menu_inicial()
        {
            InitializeComponent();
            
            txtestado.ForeColor = Color.Red;
            btnconectar.Enabled = true;
            btndesconectar.Enabled = false;
        }

        public void limpieza_reinicio()
        {
            txtnombre.Text = "";
            txtapell1.Text = "";
            txtapell2.Text = "";
            txtnombre.Enabled = false;
            txtapell1.Enabled = false;
            txtapell2.Enabled = false;
            btn_vent_art.Enabled = false;
            btn_consul_ventas.Enabled = false;
        }

        private void Abrir_ventanas(Object ventanas)
        {
            if (this.panelcentral.Controls.Count > 0) this.panelcentral.Controls.RemoveAt(0);
            Form vent = ventanas as Form;
            vent.TopLevel = false;
            vent.Dock = DockStyle.Fill;
            this.panelcentral.Controls.Add(vent);
            this.panelcentral.Tag = vent;
            vent.Show();
        }



        private void btn_vent_art_Click(object sender, EventArgs e)
        {
            if(conexion_cliente_vendedor)
            {
                Abrir_ventanas(new Venta_Articulos());
            }
            else
            {
             MessageBox.Show("Debe conectarse primero con el servidor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            Abrir_ventanas(new Venta_Articulos());
        }

        private void btn_consul_ventas_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Consulta_Ventas());
        }



        private void btncerrar_Click(object sender, EventArgs e)
        {
            var resultado = MessageBox.Show("¿Desea salir de la aplicación?", "Agregar", MessageBoxButtons.YesNo,
             MessageBoxIcon.Question);
            if (resultado == DialogResult.No)
            {
                return;
            }
            else
            {
                Application.Exit();
            }
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            var resultado = MessageBox.Show("¿Desea salir de la aplicación?", "Agregar", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);
            if (resultado == DialogResult.No)
            {
                return;
            }
            else
            {
                Application.Exit();
            }
        }

        private void btnconectar_Click(object sender, EventArgs e)
        {

            if (!(txtcedula.Text.Equals(string.Empty)))
            {
                if (TCP_Cliente.Conexion(txtcedula.Text))
                {
                    txtestado.Text = "Conectado al servidor... en (127.0.0.1, 30000)";
                    txtestado.ForeColor = Color.Green;
                    conexion_cliente_vendedor = true;
                    btnconectar.Enabled = false;
                    btndesconectar.Enabled = true;
                    txtcedula.ReadOnly = true;
                }
                else
                {
                    MessageBox.Show("Verifique que el servidor esté escuchando clientes...", "Error al conectarse", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Debe ingresar una identificación en el campo 'Vendedor' para conectarse al sevidor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


        }

        private void btnok_Click(object sender, EventArgs e)
        {


            if (!conexion_cliente_vendedor)  
            {
                MessageBox.Show("Debe conectarse al servidor para iniciar", "Error");
                limpieza_reinicio();
                return;
            }

            IDVendedor = txtcedula.Text;

            if (TCP_Cliente.Vendedor_Existe(IDVendedor))
            {
                panelopciones.Visible = true;
                btn_vent_art.Enabled = true;
                btn_consul_ventas.Enabled = true;
            }
            else
            {
                MessageBox.Show("El vendedor no existe", "ERROR");
                limpieza_reinicio();
                return;
            }

            //El vendedor existe por lo tanto se procede
            //a traer: el nombre y los apellidos
            Vendedor vende_Datos;
            vende_Datos= TCP_Cliente.Vendedor_Datos(IDVendedor);
            txtnombre.Text = vende_Datos.Nombre_Vend;
            txtapell1.Text = vende_Datos.Prim_Apell;
            txtapell2.Text = vende_Datos.Seg_Apell;
        }

        private void btndesconectar_Click_1(object sender, EventArgs e)
        {
            limpieza_reinicio();
            TCP_Cliente.Desconect(txtcedula.Text);
            txtestado.Text = "Desconectado";
            txtestado.ForeColor = Color.Red;
             btndesconectar.Enabled = false;
            btnconectar.Enabled = true;
            conexion_cliente_vendedor = false;
            txtcedula.ReadOnly = false;
            Abrir_ventanas(new Imagen_inicial());
        }
    }
}
