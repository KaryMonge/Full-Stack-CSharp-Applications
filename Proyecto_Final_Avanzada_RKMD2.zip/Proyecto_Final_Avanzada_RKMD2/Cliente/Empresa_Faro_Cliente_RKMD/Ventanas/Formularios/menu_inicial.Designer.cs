﻿
namespace Ventanas
{
    partial class menu_inicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(menu_inicial));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncerrar = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panelcentral = new System.Windows.Forms.Panel();
            this.btn_vent_art = new System.Windows.Forms.Button();
            this.btn_consul_ventas = new System.Windows.Forms.Button();
            this.btnsalir = new System.Windows.Forms.Button();
            this.panelmenu = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.txtestado = new System.Windows.Forms.TextBox();
            this.btndesconectar = new System.Windows.Forms.Button();
            this.btnconectar = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnok = new System.Windows.Forms.Button();
            this.txtcedula = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panelopciones = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtapell2 = new System.Windows.Forms.TextBox();
            this.txtapell1 = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).BeginInit();
            this.panelmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panelopciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btncerrar);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1233, 48);
            this.panel1.TabIndex = 2;
            // 
            // btncerrar
            // 
            this.btncerrar.Image = ((System.Drawing.Image)(resources.GetObject("btncerrar.Image")));
            this.btncerrar.Location = new System.Drawing.Point(1152, 3);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(34, 32);
            this.btncerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btncerrar.TabIndex = 2;
            this.btncerrar.TabStop = false;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.ForeColor = System.Drawing.Color.MediumPurple;
            this.label1.Location = new System.Drawing.Point(649, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "EMPRESA FARO S.A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label3.ForeColor = System.Drawing.Color.MediumPurple;
            this.label3.Location = new System.Drawing.Point(77, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "MENÚ INICIAL";
            // 
            // panelcentral
            // 
            this.panelcentral.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelcentral.BackgroundImage")));
            this.panelcentral.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelcentral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelcentral.Location = new System.Drawing.Point(368, 48);
            this.panelcentral.Name = "panelcentral";
            this.panelcentral.Size = new System.Drawing.Size(865, 679);
            this.panelcentral.TabIndex = 7;
            // 
            // btn_vent_art
            // 
            this.btn_vent_art.BackColor = System.Drawing.Color.DimGray;
            this.btn_vent_art.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_vent_art.FlatAppearance.BorderSize = 3;
            this.btn_vent_art.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.btn_vent_art.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_vent_art.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btn_vent_art.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_vent_art.Location = new System.Drawing.Point(10, 190);
            this.btn_vent_art.Name = "btn_vent_art";
            this.btn_vent_art.Size = new System.Drawing.Size(272, 34);
            this.btn_vent_art.TabIndex = 3;
            this.btn_vent_art.Text = " Venta de Artículos";
            this.btn_vent_art.UseVisualStyleBackColor = false;
            this.btn_vent_art.Click += new System.EventHandler(this.btn_vent_art_Click);
            // 
            // btn_consul_ventas
            // 
            this.btn_consul_ventas.BackColor = System.Drawing.Color.DimGray;
            this.btn_consul_ventas.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_consul_ventas.FlatAppearance.BorderSize = 3;
            this.btn_consul_ventas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.btn_consul_ventas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_consul_ventas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btn_consul_ventas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_consul_ventas.Location = new System.Drawing.Point(14, 263);
            this.btn_consul_ventas.Name = "btn_consul_ventas";
            this.btn_consul_ventas.Size = new System.Drawing.Size(272, 34);
            this.btn_consul_ventas.TabIndex = 4;
            this.btn_consul_ventas.Text = "Consultar Ventas";
            this.btn_consul_ventas.UseVisualStyleBackColor = false;
            this.btn_consul_ventas.Click += new System.EventHandler(this.btn_consul_ventas_Click);
            // 
            // btnsalir
            // 
            this.btnsalir.BackColor = System.Drawing.Color.DimGray;
            this.btnsalir.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnsalir.FlatAppearance.BorderSize = 3;
            this.btnsalir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.btnsalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnsalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnsalir.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsalir.Location = new System.Drawing.Point(20, 591);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(271, 33);
            this.btnsalir.TabIndex = 0;
            this.btnsalir.Text = "SALIR";
            this.btnsalir.UseVisualStyleBackColor = false;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // panelmenu
            // 
            this.panelmenu.BackColor = System.Drawing.SystemColors.ControlText;
            this.panelmenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelmenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelmenu.Controls.Add(this.pictureBox6);
            this.panelmenu.Controls.Add(this.pictureBox5);
            this.panelmenu.Controls.Add(this.txtestado);
            this.panelmenu.Controls.Add(this.btndesconectar);
            this.panelmenu.Controls.Add(this.btnconectar);
            this.panelmenu.Controls.Add(this.label5);
            this.panelmenu.Controls.Add(this.btnok);
            this.panelmenu.Controls.Add(this.txtcedula);
            this.panelmenu.Controls.Add(this.label2);
            this.panelmenu.Controls.Add(this.panelopciones);
            this.panelmenu.Controls.Add(this.btnsalir);
            this.panelmenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelmenu.Location = new System.Drawing.Point(0, 48);
            this.panelmenu.Name = "panelmenu";
            this.panelmenu.Size = new System.Drawing.Size(368, 679);
            this.panelmenu.TabIndex = 6;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(238, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(128, 61);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 49;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(300, 568);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(58, 88);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 48;
            this.pictureBox5.TabStop = false;
            // 
            // txtestado
            // 
            this.txtestado.BackColor = System.Drawing.Color.Black;
            this.txtestado.Font = new System.Drawing.Font("Lucida Calligraphy", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtestado.Location = new System.Drawing.Point(10, 70);
            this.txtestado.Name = "txtestado";
            this.txtestado.ReadOnly = true;
            this.txtestado.Size = new System.Drawing.Size(331, 22);
            this.txtestado.TabIndex = 12;
            // 
            // btndesconectar
            // 
            this.btndesconectar.BackColor = System.Drawing.Color.DimGray;
            this.btndesconectar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btndesconectar.FlatAppearance.BorderSize = 3;
            this.btndesconectar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.btndesconectar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btndesconectar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btndesconectar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btndesconectar.Location = new System.Drawing.Point(10, 108);
            this.btndesconectar.Name = "btndesconectar";
            this.btndesconectar.Size = new System.Drawing.Size(122, 34);
            this.btndesconectar.TabIndex = 11;
            this.btndesconectar.Text = "Desconectar";
            this.btndesconectar.UseVisualStyleBackColor = false;
            this.btndesconectar.Click += new System.EventHandler(this.btndesconectar_Click_1);
            // 
            // btnconectar
            // 
            this.btnconectar.BackColor = System.Drawing.Color.DimGray;
            this.btnconectar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnconectar.FlatAppearance.BorderSize = 3;
            this.btnconectar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.btnconectar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnconectar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnconectar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnconectar.Location = new System.Drawing.Point(213, 108);
            this.btnconectar.Name = "btnconectar";
            this.btnconectar.Size = new System.Drawing.Size(128, 34);
            this.btnconectar.TabIndex = 10;
            this.btnconectar.Text = "Conectar";
            this.btnconectar.UseVisualStyleBackColor = false;
            this.btnconectar.Click += new System.EventHandler(this.btnconectar_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Silver;
            this.label5.Location = new System.Drawing.Point(6, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(232, 24);
            this.label5.TabIndex = 9;
            this.label5.Text = "Estado del Servidor:";
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.Color.DimGray;
            this.btnok.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnok.FlatAppearance.BorderSize = 3;
            this.btnok.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.btnok.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnok.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnok.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnok.Location = new System.Drawing.Point(266, 187);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(75, 34);
            this.btnok.TabIndex = 8;
            this.btnok.Text = "OK";
            this.btnok.UseVisualStyleBackColor = false;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // txtcedula
            // 
            this.txtcedula.BackColor = System.Drawing.Color.Black;
            this.txtcedula.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold);
            this.txtcedula.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtcedula.Location = new System.Drawing.Point(5, 191);
            this.txtcedula.Name = "txtcedula";
            this.txtcedula.Size = new System.Drawing.Size(252, 29);
            this.txtcedula.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(6, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "Cedúla Vendedor";
            // 
            // panelopciones
            // 
            this.panelopciones.Controls.Add(this.pictureBox4);
            this.panelopciones.Controls.Add(this.label4);
            this.panelopciones.Controls.Add(this.pictureBox3);
            this.panelopciones.Controls.Add(this.pictureBox1);
            this.panelopciones.Controls.Add(this.pictureBox2);
            this.panelopciones.Controls.Add(this.label6);
            this.panelopciones.Controls.Add(this.txtapell2);
            this.panelopciones.Controls.Add(this.txtapell1);
            this.panelopciones.Controls.Add(this.txtnombre);
            this.panelopciones.Controls.Add(this.btn_vent_art);
            this.panelopciones.Controls.Add(this.btn_consul_ventas);
            this.panelopciones.Location = new System.Drawing.Point(5, 240);
            this.panelopciones.Name = "panelopciones";
            this.panelopciones.Size = new System.Drawing.Size(356, 309);
            this.panelopciones.TabIndex = 5;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(261, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(92, 53);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 49;
            this.pictureBox4.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Silver;
            this.label4.Location = new System.Drawing.Point(10, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "Vendedor (a):";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(295, 253);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(58, 53);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 48;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(292, 180);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 57);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 47;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(176, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(76, 53);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Silver;
            this.label6.Location = new System.Drawing.Point(11, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 24);
            this.label6.TabIndex = 11;
            this.label6.Text = "Trámites:";
            // 
            // txtapell2
            // 
            this.txtapell2.BackColor = System.Drawing.Color.Black;
            this.txtapell2.Font = new System.Drawing.Font("Lucida Calligraphy", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtapell2.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtapell2.Location = new System.Drawing.Point(10, 120);
            this.txtapell2.Name = "txtapell2";
            this.txtapell2.ReadOnly = true;
            this.txtapell2.Size = new System.Drawing.Size(242, 28);
            this.txtapell2.TabIndex = 10;
            // 
            // txtapell1
            // 
            this.txtapell1.BackColor = System.Drawing.Color.Black;
            this.txtapell1.Font = new System.Drawing.Font("Lucida Calligraphy", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtapell1.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtapell1.Location = new System.Drawing.Point(10, 86);
            this.txtapell1.Name = "txtapell1";
            this.txtapell1.ReadOnly = true;
            this.txtapell1.Size = new System.Drawing.Size(242, 28);
            this.txtapell1.TabIndex = 9;
            // 
            // txtnombre
            // 
            this.txtnombre.BackColor = System.Drawing.Color.Black;
            this.txtnombre.Font = new System.Drawing.Font("Lucida Calligraphy", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnombre.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtnombre.Location = new System.Drawing.Point(10, 52);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.ReadOnly = true;
            this.txtnombre.Size = new System.Drawing.Size(242, 28);
            this.txtnombre.TabIndex = 8;
            // 
            // menu_inicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1233, 727);
            this.Controls.Add(this.panelcentral);
            this.Controls.Add(this.panelmenu);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "menu_inicial";
            this.Text = "menu_inicial";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).EndInit();
            this.panelmenu.ResumeLayout(false);
            this.panelmenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panelopciones.ResumeLayout(false);
            this.panelopciones.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox btncerrar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelcentral;
        private System.Windows.Forms.Button btn_vent_art;
        private System.Windows.Forms.Button btn_consul_ventas;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.Panel panelmenu;
        private System.Windows.Forms.Panel panelopciones;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.TextBox txtcedula;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtapell2;
        private System.Windows.Forms.TextBox txtapell1;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtestado;
        private System.Windows.Forms.Button btndesconectar;
        private System.Windows.Forms.Button btnconectar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}