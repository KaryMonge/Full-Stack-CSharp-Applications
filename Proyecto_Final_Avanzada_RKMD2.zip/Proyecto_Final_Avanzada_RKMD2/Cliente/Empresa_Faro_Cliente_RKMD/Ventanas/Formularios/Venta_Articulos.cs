﻿using Entidades.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Ventanas.Formularios
{
    public partial class Venta_Articulos : Form
    {

        int contador_compras = 0;
        int contador_detalle = 0;
        DateTime dia = DateTime.Now;

        public void limpiar_ventana()
        {
            txt_id_compra.Clear();
            txt_fecha.Clear();
            txt_id_del_articulo.Clear();
            txt_cantidad_deseada.Clear();
            dataGridViewmostrar_elecion.Rows.Clear();
            //se puede realizar la compra
            //se define el contador de compras como el mayor en la base de datos más 1
            contador_compras = TCP_Cliente.obtener_mayor_ordencompra_tcp() + 1;
            txt_id_compra.Text = contador_compras.ToString();

            // se define el contador de detalle como el mayor en la base de datos más 1
            contador_detalle = TCP_Cliente.obtener_mayor_ordencompradetalle_tcp() + 1;

            txt_fecha.Text = dia.ToShortDateString();
        }
        public Venta_Articulos()
        {

            InitializeComponent();
 
            int contador_articulos = 0;

            //Traer los artículos en una lista de artículos
            List<Articulo> lista_articulos = new List<Articulo>();
             lista_articulos = TCP_Cliente.obtener_datos_articulos_tcp();

            //Llenado del datagrid con los datos de los artículos
            foreach (Articulo articulo_leido in lista_articulos)
            {
                contador_articulos++;
                dataGridView_mostrar_articulos.Rows.Add(articulo_leido.Id_Articulo, articulo_leido.Descripcion, articulo_leido.Precio_Vend, articulo_leido.Precio_Final, articulo_leido.Cantidad_Disponible);
            }

            //Si el contador de artículos está en 0 significa que la lista venía vacía y que
            //el foreach no se ejecutó
            if (contador_articulos == 0)
            {
                MessageBox.Show("No existen artículos, no se puede realizar la venta", "ERROR");
                return;
            }
            else
            {
                //se puede realizar la compra

                txt_fecha.Text = dia.ToShortDateString();

                //se define el contador de compras como el mayor en la base de datos más 1
                contador_compras = TCP_Cliente.obtener_mayor_ordencompra_tcp() + 1;
                txt_id_compra.Text = contador_compras.ToString();

               // se define el contador de detalle como el mayor en la base de datos más 1
               contador_detalle = TCP_Cliente.obtener_mayor_ordencompradetalle_tcp() + 1;
            }
        }

        private void limpiar()
        {

            txt_id_del_articulo.Text = string.Empty;
            txt_cantidad_deseada.Text = string.Empty;
        }

        private void btnagregar_Click_1(object sender, EventArgs e)
        {
            try
            {

                if (int.Parse(txt_cantidad_deseada.Text) <= 0 ||
                   int.Parse(txt_id_del_articulo.Text) < 0)
                {
                    MessageBox.Show("Por favor, introduzca solo nùmeros positivos.");
                    limpiar();
                    return;
                }
                if (string.IsNullOrEmpty(txt_id_del_articulo.Text) || string.IsNullOrEmpty(txt_cantidad_deseada.Text))
                {
                    MessageBox.Show("Debe digitar los campos correctamente", "ERROR");
                    limpiar();
                    return;
                }

                string arti_descrip = "";
                decimal arti_precio_vende = 0;
                decimal arti_precio_fin = 0;
                int arti_cant_disp = 0;

                bool articulo_encontrado = false;

                //ciclo para buscar el articulo que digito el usuario en el datagridview
                foreach (DataGridViewRow fila in dataGridView_mostrar_articulos.Rows)
                {
                    //DataGridViewCell =fila.Cells[0]
                    //El DataGridViewCell siempre debe ser convertido a un tipo de datos

                    if (fila.Cells[0].Value.ToString().Equals(txt_id_del_articulo.Text))
                    {
                        //Encontré el artículo
                        articulo_encontrado = true;
                        arti_descrip = fila.Cells[1].Value.ToString();
                        arti_precio_vende = Decimal.Parse(fila.Cells[2].Value.ToString());
                        arti_precio_fin = Decimal.Parse(fila.Cells[3].Value.ToString());
                        arti_cant_disp = Int32.Parse(fila.Cells[4].Value.ToString());
                        break;
                    }
                }

                if (!articulo_encontrado)
                {
                    MessageBox.Show("La Identificación " + txt_id_del_articulo.Text + " NO existe", "ERROR");
                    limpiar();
                    return;
                }

                if (arti_cant_disp < int.Parse(txt_cantidad_deseada.Text))
                {
                    MessageBox.Show("No se puede agregar el artículo, verifique la cantidad disponible", "ERROR");
                    limpiar();
                    return;
                }

                //Se pasó el filtro:  el artículo existe y la cantidad es menor a la cantidad disponible
                //Esto significa que el artículo se puede agregar al carrito

                //Paso 1
                //Agregar al datagrid del carrito
                dataGridViewmostrar_elecion.Rows.Add(contador_detalle, txt_id_del_articulo.Text, int.Parse(txt_cantidad_deseada.Text), arti_precio_vende, arti_precio_fin);
                contador_detalle++;

                //Paso 2
                //Actualizar el inventario del grid

                int contador_filas = 0;
                foreach (DataGridViewRow fila in dataGridView_mostrar_articulos.Rows)
                {

                    if (fila.Cells[0].Value.ToString().Equals(txt_id_del_articulo.Text))
                    {
                        //Encontré el artículo
                        arti_cant_disp = Int32.Parse(fila.Cells[4].Value.ToString());
                        //Se define la nueva cantidad disponible (columna 4 del Grid) como 
                        //la cantidad que tenia capturada en la variable arti_cant_disp
                        //menos la cantidad digitada por el usuario
                        dataGridView_mostrar_articulos.Rows[contador_filas].Cells[4].Value = arti_cant_disp - int.Parse(txt_cantidad_deseada.Text);
                        break;
                    }
                    contador_filas++;
                }

                limpiar();
            }
            catch (FormatException)
            {
                MessageBox.Show("Digite los campos solicitados correctamente");
            }
        }

        private void btn_finalizar_Click(object sender, EventArgs e)
        {

            //Validar que haya detalle de orden de compra
            int contador_filas = 0;
            foreach (DataGridViewRow fila in dataGridViewmostrar_elecion.Rows)
            {// si existen detalles enntonces va incrementando el contador ++
                contador_filas++;
            }
            if (contador_filas == 0)
            {// Si es igual a 0 es porque no existe detalle y lanza este error 
                MessageBox.Show("No existe detalle de orden de compra", "ERROR");
                return;
            }

            OrdenCompra orden_compra_finalizada = new OrdenCompra();

            orden_compra_finalizada.Id_Compra = contador_compras;
            orden_compra_finalizada.Vendedor = menu_inicial.IDVendedor;
            orden_compra_finalizada.Fecha = dia;

            TCP_Cliente.ordencompra_insertar_tcp(orden_compra_finalizada);
            
            List<OrdenCompraDetalle> lista_detalles = new List<OrdenCompraDetalle>();
            //Se recorre el datagridview y se van creando los elementos de la lista
            foreach (DataGridViewRow fila in dataGridViewmostrar_elecion.Rows)
            {
                OrdenCompraDetalle ordencita = new OrdenCompraDetalle();
                ordencita.IdDetalle = Int32.Parse(fila.Cells[0].Value.ToString());
                ordencita.Id_Compra = contador_compras;
                ordencita.Id_Articulo = Int32.Parse(fila.Cells[1].Value.ToString());
                ordencita.Cantidad = Int32.Parse(fila.Cells[2].Value.ToString());
                ordencita.Precio_Vend = Decimal.Parse(fila.Cells[3].Value.ToString());
                ordencita.Precio_Final = Decimal.Parse(fila.Cells[4].Value.ToString());
                lista_detalles.Add(ordencita);
            }

            TCP_Cliente.detalle_ordencompra_insertar_tcp(lista_detalles);
            
            List<Articulo> lista_articulos = new List<Articulo>();
            foreach (DataGridViewRow fila in dataGridView_mostrar_articulos.Rows)
            {
                Articulo articulo_inv = new Articulo();
                articulo_inv.Id_Articulo = Int32.Parse(fila.Cells[0].Value.ToString());
                articulo_inv.Cantidad_Disponible = Int32.Parse(fila.Cells[4].Value.ToString());
                lista_articulos.Add(articulo_inv);
            }

            TCP_Cliente.actualizar_inventario_tcp(lista_articulos);

            MessageBox.Show("Se ha realizado la Compra exitosamente", "Finalizado");

            //  la limpieza o cierre de la pantalla.
            limpiar_ventana();
            
        }


    }
}
