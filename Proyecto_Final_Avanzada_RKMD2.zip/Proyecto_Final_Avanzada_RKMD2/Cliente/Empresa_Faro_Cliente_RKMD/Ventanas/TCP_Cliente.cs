﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using Entidades.Clases;
using Newtonsoft.Json;

namespace Ventanas
{
    class TCP_Cliente
    {
        private static IPAddress Servidor_IP;
        private static TcpClient Clientes;
        private static IPEndPoint EndPoint;
        private static StreamWriter C_streamwriter;
        private static StreamReader C_streamsreader;

        public static bool Conexion(string cliente_vendedor)
        {
            try
            {
                Servidor_IP = IPAddress.Parse("127.0.0.1");
                Clientes = new TcpClient();
                EndPoint = new IPEndPoint(Servidor_IP, 16830);
                Clientes.Connect(EndPoint);
              

                Sockets<string> conexion_mesage = new Sockets<string> { Metod = "Conexion", Entity = cliente_vendedor };

                C_streamsreader = new StreamReader(Clientes.GetStream());
                C_streamwriter = new StreamWriter(Clientes.GetStream());
                C_streamwriter.WriteLine(JsonConvert.SerializeObject(conexion_mesage));
                C_streamwriter.Flush();
            }
            catch (SocketException)
            {
                return false;
            }
            return true;
        }

        public static void Desconect(string cliente_vendedor)
        {
            try
            {
                Sockets<string> desconect_message = new Sockets<string> { Metod = "desconect", Entity = cliente_vendedor };

                C_streamwriter.WriteLine(JsonConvert.SerializeObject(desconect_message));
                C_streamwriter.Flush();

                Clientes.Close();
            }
            catch (Exception E)
            { 
                Clientes.Close();
                return;
            }
        }

        /// <summary>
        /// Envía al servidor un articulo
        /// </summary>
        /// <param name="Idarticulo">Nuevo articulo</param>
        public static List<Articulo> Obtener_articulos(string Idarticulo)
        {
            List<Articulo> articulos = new List<Articulo>();
            Sockets<string> obtener_lista_articulos = new Sockets<string> { Metod = "Obtener_articulos", Entity = Idarticulo };

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(obtener_lista_articulos));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            articulos = JsonConvert.DeserializeObject<List<Articulo>>(message);

            return articulos;
        }


        /// <summary>
        /// Envía al servidor un Vendedor
        /// </summary>
        /// <param name="IDvendedor">Vendedor</param>
        public static bool Vendedor_Existe(string IDvendedor)
        {
            Sockets<string> mensajeVendedores = new Sockets<string> { Metod = "Vendedor_Existe", Entity = IDvendedor };

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajeVendedores));
            C_streamwriter.Flush();
            
            var message = C_streamsreader.ReadLine();
            bool existe = JsonConvert.DeserializeObject<bool>(message);
            return existe;

        }


        public static Vendedor Vendedor_Datos(string IDvendedor)
        {
            Sockets<string> mensajeVendedores = new Sockets<string> { Metod = "Vendedor_Datos", Entity = IDvendedor };

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajeVendedores));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            Vendedor Datos_V = JsonConvert.DeserializeObject<Vendedor>(message);
            return Datos_V ;
        }

        
        public static List<Articulo> obtener_datos_articulos_tcp()
        {
            Sockets<string> mensajeArticulos = new Sockets<string> { Metod = "Obtener_Datos_Articulos", Entity = "" };

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajeArticulos));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            List<Articulo> Lista_A = new List<Articulo>();
            Lista_A = JsonConvert.DeserializeObject<List<Articulo>>(message);
            return Lista_A;
        }

        

        public static int obtener_mayor_ordencompra_tcp()
        {
            Sockets<string> mensajeOrdencompra = new Sockets<string> { Metod = "Obtener_Mayor_Ordencompra", Entity = "" };// entity seria el parámetro que se manda, en este caso va vacío

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajeOrdencompra));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            return JsonConvert.DeserializeObject<int>(message);
        }

        public static int obtener_mayor_ordencompra_x_vendedor_tcp(string IDVendedor)
        {
            Sockets<string> mensajeOrdencompra_V = new Sockets<string> { Metod = "Obtener_Mayor_Ordencompra_V", Entity = IDVendedor };// entity seria el parámetro que se manda, en este caso va vacío

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajeOrdencompra_V));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            return JsonConvert.DeserializeObject<int>(message);
        }

        public static List<OrdenCompra> obtener_datos_ordencompra_x_vendedor_tcp(string IDVendedor)
        {
            Sockets<string> mensajedatosOrdencompra_V = new Sockets<string> { Metod = "Obtener_datos_Ordencompra_V", Entity = IDVendedor };// entity seria el parámetro que se manda, en este caso va vacío

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajedatosOrdencompra_V));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            List<OrdenCompra> Lista_Orden = new List<OrdenCompra>();
            Lista_Orden = JsonConvert.DeserializeObject<List<OrdenCompra>>(message);
            return Lista_Orden;
        }

        public static int obtener_mayor_ordencompradetalle_tcp()
        {
            Sockets<string> mensajeOrdencompradetalle = new Sockets<string> { Metod = "Obtener_Mayor_OrdencompraDetalle", Entity = "" };// entity seria el parámetro que se manda, en este caso va vacío

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajeOrdencompradetalle));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            return JsonConvert.DeserializeObject<int>(message);
        }


        public static void ordencompra_insertar_tcp(OrdenCompra  la_compris)
        {

            Sockets<OrdenCompra> mensaje_insertOrdencompra= new Sockets<OrdenCompra> { Metod = "Insertar_Ordencompra", Entity = la_compris };

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensaje_insertOrdencompra));
            C_streamwriter.Flush();
        }


        public static void detalle_ordencompra_insertar_tcp(List<OrdenCompraDetalle> la_lista_delascompris)
        {

            Sockets<List<OrdenCompraDetalle>> mensaje_insertDetalleOrdencompra = new Sockets<List<OrdenCompraDetalle>> { Metod = "Insertar_DetalleOrdencompra", Entity = la_lista_delascompris };

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensaje_insertDetalleOrdencompra));
            C_streamwriter.Flush();
        }
        public static void actualizar_inventario_tcp(List<Articulo> lista_A)
        {

            Sockets<List<Articulo>> mensaje_actualizarinventario = new Sockets<List<Articulo>> { Metod = "Actualizar_Inventario", Entity = lista_A };

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensaje_actualizarinventario));
            C_streamwriter.Flush();
        }

        public static OrdenCompra obtener_datos_una_ordencompra_tcp(int id_compra)
        {
            Sockets<int> mensajedatosOrdencompra = new Sockets<int> { Metod = "Obtener_datos_Ordencompra", Entity = id_compra };// entity seria el parámetro que se manda, en este caso va vacío

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajedatosOrdencompra));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            OrdenCompra Orden_V;
            Orden_V = JsonConvert.DeserializeObject<OrdenCompra>(message);
            return Orden_V;
        }

        public static List<OrdenCompraDetalle> obtener_datos_detalleordencompra_tcp(int id_compra)
        {
            Sockets<int> mensajedatosOrdencompraDet = new Sockets<int> { Metod = "Obtener_datos_OrdencompraDet_V", Entity = id_compra };// entity seria el parámetro que se manda, en este caso va vacío

            C_streamwriter.WriteLine(JsonConvert.SerializeObject(mensajedatosOrdencompraDet));
            C_streamwriter.Flush();

            var message = C_streamsreader.ReadLine();
            List<OrdenCompraDetalle> Lista_OrdenDet_V = new List<OrdenCompraDetalle>();
            Lista_OrdenDet_V = JsonConvert.DeserializeObject<List<OrdenCompraDetalle>>(message);
            return Lista_OrdenDet_V;

        }
    }
}
