﻿using Entidades.Clases;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Base_Datos.Conexion_DB.Acceso_Datos;

namespace Negocios.Utilidades
{
  public static class Extend_Bd
    {

        public static List<Vendedor> obtener_datos_vendedores_Negocio()
        {
            return obtener_datos_vendedores();

        }

        public static bool articulo_existe_Negocio(int Idarticulo)
        { 
            return articulo_existe(Idarticulo);
        }


        public static void articulo_insertar_Negocio(Articulo nuevo_articulo)
        {
            articulo_insertar(nuevo_articulo);
        }

        public static bool Vendedor_existe_Negocio(string Idvendedor)
        {
           return Vendedor_existe( Idvendedor);
        }


        public static void vendedor_insertar_Negocio(Vendedor nuevo_vendedor)
        {

            vendedor_insertar(nuevo_vendedor);
        }

        public static List<Articulo> obtener_datos_articulos_Negocio()
        {
            
            return obtener_datos_articulos();

        }

        public static Vendedor obtener_datos_un_vendedor_Negocio(string Idvendedor)
        {
            return obtener_datos_un_vendedor(Idvendedor);
        }

        public static int obtener_mayor_detalle_Megocio()
        {
            return obtener_mayor_detalle();
        }

        public static int obtener_mayor_ordencompra_Megocio()
        {
            return obtener_mayor_ordencompra();
        }

        public static void ordencompra_insertar_Negocio(OrdenCompra nueva_orden)
        {
            ordencompra_insertar(nueva_orden);
        }

        public static void detalle_ordencompra_insertar_Negocio(List<OrdenCompraDetalle> lista_detalle)
        {
            detalle_ordencompra_insertar(lista_detalle);
        }

        public static void actualizar_inventario_Negocio(List<Articulo> lista_articulos)
        {
            actualizar_inventario(lista_articulos);
        }

        public static List<OrdenCompra> obtener_datos_ordencompra_Negocio()
        {
            return obtener_datos_ordencompra();
        }

        public static OrdenCompra obtener_datos_una_ordencompra_Negocio(int Idcompra)
        {
            return obtener_datos_una_ordencompra(Idcompra);
        }
        public static List<OrdenCompraDetalle> obtener_datos_detalleordencompra_Negocio(int Idcompra)
        {
            return obtener_datos_detalleordencompra(Idcompra);
        }

        public static List<Articulo> obtener_datostotales_articulos_Negocio()
        {
            return obtener_datostotales_articulos();
        }
        public static void actualizar_articulos_update_Negocio(int idArticulo, bool activo, decimal precio_vendedor, decimal precio_final, int cantidad_disponible)
        {
            actualizar_articulos_update(idArticulo, activo, precio_vendedor, precio_final, cantidad_disponible);
        }
  }
}
