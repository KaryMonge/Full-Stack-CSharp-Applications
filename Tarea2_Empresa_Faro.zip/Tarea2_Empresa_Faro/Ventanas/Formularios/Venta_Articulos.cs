﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Negocios.Utilidades.Extend_Bd;
using static Entidades.Clases.Articulo;
using static Entidades.Clases.OrdenCompra;
using  Entidades.Clases;
namespace Ventanas.Sub_menu
{
    public partial class Venta_Articulos : Form
    {

        public void limpiar_ventana()
        {
            comboBoxid_vendedores.SelectedIndex = -1;
            txt_id_compra.Clear();
            txt_1apellido.Clear();
            txt_2pellido.Clear();
            txt_fecha_comp.Clear();
            txt_id_compra.Clear();
            txt_id_del_articulo.Clear();
            txt_cantidad_deseada.Clear();
            dataGridViewmostrar_elecion.Rows.Clear();
            //se puede realizar la compra
            //se define el contador de compras como el mayor en la base de datos más 1
            contador_compras = obtener_mayor_ordencompra_Megocio() + 1;
            txt_id_compra.Text = contador_compras.ToString();
            //se define el contador de detalle como el mayor en la base de datos más 1
            contador_detalle = obtener_mayor_detalle_Megocio() + 1;
        }
        // List<OrdenCompraDetalle> desgloce_compras = new List<OrdenCompraDetalle>();

        int contador_compras = 0;
        int contador_detalle = 0;

        public Venta_Articulos()
        {
            InitializeComponent();

            int contador_vendedores = 0;
            int contador_articulos = 0;

            //Llenado de vendores
            List<Vendedor> lista_vendedores = new List<Vendedor>();
            lista_vendedores = obtener_datos_vendedores_Negocio();

            //Llenado del combobox con los vendedores que vienen en la lista
            foreach (Vendedor vendedor_leido in lista_vendedores)
            {
                contador_vendedores++;
                comboBoxid_vendedores.Items.Add(vendedor_leido.Ident_Vend);
            }

            //Si el contador de vendedores está en 0 significa que la lista venía vacía y que
            //el foreach no se ejecutó
            if(contador_vendedores == 0)
            {
                MessageBox.Show("No existen Vendedores, no se puede realizar la venta", "ERROR");
                return;
            }

            //Traer los artículos en una lista de artículos
            List<Articulo> lista_articulos = new List<Articulo>();
            lista_articulos = obtener_datos_articulos_Negocio();

            //Llenado del datagrid con los datos de los artículos
            foreach (Articulo articulo_leido in lista_articulos)
            {
                contador_articulos++;
                dataGridView_mostrar_articulos.Rows.Add(articulo_leido.Id_Articulo, articulo_leido.Descripcion, articulo_leido.Precio_Vend, articulo_leido.Precio_Final, articulo_leido.Cantidad_Disponible);
            }

            //Si el contador de artículos está en 0 significa que la lista venía vacía y que
            //el foreach no se ejecutó
            if (contador_articulos == 0)
            {
                MessageBox.Show("No existen artículos, no se puede realizar la venta", "ERROR");
                return;
            }
            else
            {
                //se puede realizar la compra
                //se define el contador de compras como el mayor en la base de datos más 1
                contador_compras = obtener_mayor_ordencompra_Megocio() + 1;
                txt_id_compra.Text = contador_compras.ToString();

                //se define el contador de detalle como el mayor en la base de datos más 1
                contador_detalle = obtener_mayor_detalle_Megocio() + 1;
            }

        }
         
        
        string id_vendedor;
        DateTime dia = DateTime.Now;

        private void limpiar()
        {
            txt_id_del_articulo.Text = string.Empty;
            txt_cantidad_deseada.Text = string.Empty;
        }

        private void comboBoxid_vendedores_SelectedIndexChanged(object sender, EventArgs e)
        {
            id_vendedor = comboBoxid_vendedores.Text;
            Vendedor vendedor_seleccionado = new Vendedor();
            vendedor_seleccionado = obtener_datos_un_vendedor_Negocio(id_vendedor);
            txt_Nomb_Vend.Text = vendedor_seleccionado.Nombre_Vend;
            txt_1apellido.Text = vendedor_seleccionado.Prim_Apell;
            txt_2pellido.Text = vendedor_seleccionado.Seg_Apell;
            txt_fecha_comp.Text = dia.ToShortDateString();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {

            try
            {
                if(comboBoxid_vendedores.Text == "")
                {//si no hay ids en el combobox de vendedores, no se podrá realizar la venta
                 MessageBox.Show("Debe seleccionar un vendedor para realizar la compra.");
                    limpiar();
                    return;
                }

                if (int.Parse(txt_cantidad_deseada.Text) <= 0 ||
                   int.Parse(txt_id_del_articulo.Text) < 0)
                {
                    MessageBox.Show("Por favor, introduzca solo nùmeros positivos.");
                    limpiar();
                    return;
                }     

                if (string.IsNullOrEmpty(txt_id_del_articulo.Text) || string.IsNullOrEmpty(txt_cantidad_deseada.Text))
                {
                    MessageBox.Show("Debe digitar los campos correctamente", "ERROR");
                    limpiar();
                    return;
                }
        
                string arti_descrip = "";
                decimal arti_precio_vende = 0;
                decimal arti_precio_fin = 0;
                int arti_cant_disp = 0;

                bool articulo_encontrado = false;

                //ciclo para buscar el articulo que digito el usuario en el datagridview
                foreach (DataGridViewRow fila in dataGridView_mostrar_articulos.Rows)
                {

                    //DataGridViewCell =fila.Cells[0]
                    //El DataGridViewCell siempre debe ser convertido a un tipo de datos

                    if (fila.Cells[0].Value.ToString().Equals(txt_id_del_articulo.Text))
                    {
                        //Encontré el artículo
                        articulo_encontrado = true;
                        arti_descrip = fila.Cells[1].Value.ToString();
                        arti_precio_vende = Decimal.Parse(fila.Cells[2].Value.ToString());
                        arti_precio_fin = Decimal.Parse(fila.Cells[3].Value.ToString());
                        arti_cant_disp = Int32.Parse(fila.Cells[4].Value.ToString());
                        break;
                    }
                }

                if (!articulo_encontrado)
                {
                    MessageBox.Show("La Identificación " + txt_id_del_articulo.Text + " NO existe", "ERROR");
                    limpiar();
                    return;
                }
                
                if (arti_cant_disp < int.Parse(txt_cantidad_deseada.Text))
                {
                    MessageBox.Show("No se puede agregar el artículo, verifique la cantidad disponible", "ERROR");
                    limpiar();
                    return;
                }

                //Se pasó el filtro:  el artículo existe y la cantidad es menor a la cantidad disponible
                //Esto significa que el artículo se puede agregar al carrito

                 //Paso 1
                //Agregar al datagrid del carrito
                dataGridViewmostrar_elecion.Rows.Add(contador_detalle, txt_id_del_articulo.Text, int.Parse(txt_cantidad_deseada.Text), arti_precio_vende, arti_precio_fin);
                contador_detalle++;

                //Paso 2
                //Actualizar el inventario del grid

                int contador_filas = 0;
                foreach (DataGridViewRow fila in dataGridView_mostrar_articulos.Rows)
                {
                    
                    if (fila.Cells[0].Value.ToString().Equals(txt_id_del_articulo.Text))
                    {
                        //Encontré el artículo
                        arti_cant_disp = Int32.Parse(fila.Cells[4].Value.ToString());
                        dataGridView_mostrar_articulos.Rows[contador_filas].Cells[4].Value = arti_cant_disp - int.Parse(txt_cantidad_deseada.Text);
                        break;
                    }
                    contador_filas++;
                }
                
                limpiar();
            }
            catch (FormatException)
            {
                MessageBox.Show("Digite los campos solicitados correctamente");
            }

        }

        private void btn_finalizar_Click(object sender, EventArgs e)
        {
            //Validar que haya detalle de orden de compra
            int contador_filas = 0;
            foreach (DataGridViewRow fila in dataGridViewmostrar_elecion.Rows)
            {// si existen detalles enntonces va incrementando el contador ++
                contador_filas++;
            }
            if(contador_filas==0)
            {// Si es igual a 0 es porque no existe detalle y lanza este error 
                MessageBox.Show("No existe detalle de orden de compra", "ERROR");
                return;
            }

            OrdenCompra orden_compra_finalizada = new OrdenCompra();

            orden_compra_finalizada.Id_Compra = contador_compras;
            orden_compra_finalizada.Vendedor = id_vendedor;
            orden_compra_finalizada.Fecha = dia;

            ordencompra_insertar_Negocio(orden_compra_finalizada);

            List<OrdenCompraDetalle> lista_detalles = new List<OrdenCompraDetalle>();
            foreach (DataGridViewRow fila in dataGridViewmostrar_elecion.Rows)
            {
                OrdenCompraDetalle ordencita = new OrdenCompraDetalle();
                ordencita.IdDetalle = Int32.Parse(fila.Cells[0].Value.ToString());
                ordencita.Id_Compra = contador_compras;
                ordencita.Id_Articulo = Int32.Parse(fila.Cells[1].Value.ToString());
                ordencita.Cantidad = Int32.Parse(fila.Cells[2].Value.ToString());
                ordencita.Precio_Vend = Decimal.Parse(fila.Cells[3].Value.ToString());
                ordencita.Precio_Final = Decimal.Parse(fila.Cells[4].Value.ToString());
                lista_detalles.Add(ordencita);
            }

            detalle_ordencompra_insertar_Negocio(lista_detalles);

            List<Articulo> lista_articulos = new List<Articulo>();
            foreach (DataGridViewRow fila in dataGridView_mostrar_articulos.Rows)
            {
                Articulo articulo_inv = new Articulo();
                articulo_inv.Id_Articulo = Int32.Parse(fila.Cells[0].Value.ToString());
                articulo_inv.Cantidad_Disponible = Int32.Parse(fila.Cells[4].Value.ToString());
                lista_articulos.Add(articulo_inv);
            }
            actualizar_inventario_Negocio(lista_articulos);

            MessageBox.Show("Se ha realizado la Compra exitosamente", "Finalizado");

            //  la limpieza o cierre de la pantalla.
            limpiar_ventana();


        }
    }
}
