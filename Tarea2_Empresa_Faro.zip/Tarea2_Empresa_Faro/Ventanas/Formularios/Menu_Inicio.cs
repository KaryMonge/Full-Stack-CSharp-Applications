﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ventanas.Formularios;
using Ventanas.Sub_menu;

namespace Ventanas

{
   
   public partial class Menu_Inicio : Form



    {
      
        public Menu_Inicio()
        {
            InitializeComponent();
        }



        private void Abrir_ventanas(Object ventanas)
        {
           if (this.panelcentral.Controls.Count > 0) this.panelcentral.Controls.RemoveAt(0);   
            Form vent = ventanas as Form;
            vent.TopLevel = false;
            vent.Dock = DockStyle.Fill;     
            this.panelcentral.Controls.Add(vent);
            this.panelcentral.Tag = vent;
            vent.Show();

        }

        private void btnreg_art_Click(object sender, EventArgs e)
        {    
            Abrir_ventanas(new Regristro_articulos());
        }
        private void btn_consultar_inventario_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Consulta_Inventario());
        }



        private void btn_vent_art_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Venta_Articulos());
        }

        private void btn_consul_ventas_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Consulta_Ventas());
        }

        private void btnreg_vendedores_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Registro_Vendedores());
        }

        private void btn_actualizar_inventario_Click(object sender, EventArgs e)
        {
            Abrir_ventanas(new Actualizar_inventario());
        }

        private void btncerrar_Click(object sender, EventArgs e)
        {  
                Application.Exit();
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            var resultado = MessageBox.Show("¿Desea salir de la aplicación?", "Agregar", MessageBoxButtons.YesNo,
             MessageBoxIcon.Question);
            if (resultado == DialogResult.No)
            {
                return;
            }
            else
            {
                Application.Exit();
            }

            
        }

        private void panelcentral_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    
}
