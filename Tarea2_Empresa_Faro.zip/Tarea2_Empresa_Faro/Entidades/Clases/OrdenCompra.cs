﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clases
{
   public class OrdenCompra
    {
        public int Id_Compra { get; set; }
        public DateTime Fecha { get; set; }
        public string Vendedor { get; set; }
        public string Nombre_Vend { get; set; }
        public string Prim_Apell { get; set; }
        public string Seg_Apell { get; set; }
        public OrdenCompra()
        {
            Id_Compra = 0;

            Fecha = DateTime.MinValue;

            Vendedor = "";

            Nombre_Vend = string.Empty;

            Prim_Apell = string.Empty;

            Seg_Apell = string.Empty;

        }
    }
}
