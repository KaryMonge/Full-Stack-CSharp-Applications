﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clases
{
   public class OrdenCompraDetalle
    {

        public int IdDetalle { get; set; }
        public int Id_Compra { get; set; }
        public int Id_Articulo { get; set; }
        public int Cantidad { get; set; }
        public decimal Precio_Vend { get; set; }
        public decimal Precio_Final { get; set; }
        public string Descripcion { get; set; }
        public OrdenCompraDetalle()
        {

          IdDetalle = 0;
          Id_Compra = 0;
          Id_Articulo = 0;
          Cantidad = 0;
          Precio_Vend = 0;
          Precio_Final = 0;
          Descripcion = string.Empty;

        }

   }
}



