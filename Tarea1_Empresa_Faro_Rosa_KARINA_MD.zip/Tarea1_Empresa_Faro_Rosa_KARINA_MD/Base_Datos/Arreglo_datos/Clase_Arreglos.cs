﻿using Entidades.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Entidades.Clases.OrdenCompra;

namespace Base_Datos.Arreglo_datos
{
   public  class Clase_Arreglos
    {
        public static Articulo[] Lista_Articulos = new Articulo[20];
        public static Vendedor[] Lista_Vendedores = new Vendedor[20];
        public static OrdenCompra[] Lista_Compras = new OrdenCompra[20];
        public static OrdenCompraDetalle[] Detalle = new OrdenCompraDetalle[15];



    }
}
