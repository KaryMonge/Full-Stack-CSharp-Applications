﻿using Entidades.Clases;
using Negocios.Servicios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using static Negocios.Servicios.Funciones_programa;

namespace Ventanas.Sub_menu
{




    public partial class Regristro_articulos : Form
    {
        public Regristro_articulos()
        {
            InitializeComponent();
        }

        private void limpiar()
        {
            txt_id_articulo.Text = string.Empty;
            txtdescripcion.Text = string.Empty;
            radioButtonSI.Checked = true;
            radioButtonNO.Checked = false;
            txtprecio_vend.Text = "";
            txtprecio_final.Text = "";
            txtcant_disponible.Text = "";
        }

        private void btninicio_Click(object sender, EventArgs e)
        {
            //se regresa al menú inicial
            Menu_Inicio ventana_inicio = new Menu_Inicio();
            this.Hide();
            ventana_inicio.Show();
            
        }

        private void btnregistrar_Click(object sender, EventArgs e)
        {




            try
            {

                if (Contador_Articulos() == 20)
                {
                    MessageBox.Show("La lista de artículos ya está llena");
                }

                bool activ = false;
                if (radioButtonSI.Checked == true)
                {
                    activ = true;
                }
                else if (radioButtonNO.Checked == true)
                {
                    activ = false;
                }
                else  
                {
                 MessageBox.Show("Debe seleccionar un tipo de ACTIVO");
                }

                Articulo cosito = new Articulo()

                {
                    Id_Articulo = int.Parse(txt_id_articulo.Text),
                    Descripcion = txtdescripcion.Text,
                    Activo = activ,
                    Precio_Vend = decimal.Parse(txtprecio_vend.Text),
                    Precio_Final = decimal.Parse(txtprecio_final.Text),
                    Cantidad_Disponible = int.Parse(txtcant_disponible.Text)
                };

                 if ( int.Parse(txt_id_articulo.Text) < 0 ||
                      decimal.Parse(txtprecio_vend.Text) <0|| decimal.Parse(txtprecio_final.Text) <0 ||
                      int.Parse(txtcant_disponible.Text)<0 )
                {
                    MessageBox.Show("Por favor, introduzca solo nùmeros positivos.");
                    limpiar();
                    return;

                }
                if (string.IsNullOrEmpty(txt_id_articulo.Text) || string.IsNullOrEmpty(txtdescripcion.Text) ||
                    string.IsNullOrEmpty(txtprecio_vend.Text) || string.IsNullOrEmpty(txtprecio_final.Text)
                   || string.IsNullOrEmpty(txtcant_disponible.Text))

                {
                    MessageBox.Show("Debe digitar todos los campos", "ERROR");
                    return;
                }
                if (Producto_existe(cosito.Id_Articulo))
                {
                    MessageBox.Show("La Identificación " + txt_id_articulo.Text + " ya existe", "ERROR");
                }
                else
                {
                    Agregar_articulo( cosito);


                    var resultado = MessageBox.Show("¿Desea agregrar otro Artículo?", "Agregar", MessageBoxButtons.YesNo,
                     MessageBoxIcon.Question);
                    if (resultado == DialogResult.No)
                    {
                        limpiar();
                    }
                    else
                    {
                        limpiar();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Debe digitar los campos correctamente", "ERROR");
                MessageBox.Show("Verifique digitar solo números positivos", "ERROR");
                limpiar();
            }

        }


    }
}
