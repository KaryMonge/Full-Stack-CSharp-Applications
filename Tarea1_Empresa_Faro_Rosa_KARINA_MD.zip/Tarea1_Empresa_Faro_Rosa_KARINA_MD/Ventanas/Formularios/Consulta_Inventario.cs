﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clases;
using Negocios.Servicios;
using static Negocios.Servicios.Funciones_programa;


namespace Ventanas.Formularios
{
    public partial class Consulta_Inventario : Form
    {
        public Consulta_Inventario()
        {
            InitializeComponent();
            
            int contador_articulo = Contador_Articulos();
            int id_art = 0;
            string descri = "";
            decimal precio_vende = 0;
            decimal precio_fin = 0;
            int cant_disp = 0;
            bool activo = true;
            string St_Activo = "";

            if (contador_articulo == 0)
            {
                MessageBox.Show("La lista de artículos está vacía");
                return;
            }
            
            for (int i = 0; i < contador_articulo; i++)
            {
                extraer_datos_Articuls(i, ref id_art, ref descri, ref precio_vende, ref precio_fin, ref cant_disp, ref activo);
                if (activo)
                {
                    St_Activo = "Si";
                }
                else
                {
                    St_Activo = "No";
                }

                dataGrid_Consultar_inv.Rows.Add(id_art, cant_disp, descri, St_Activo, precio_vende, precio_fin);

            }

        }
  





    }

}
