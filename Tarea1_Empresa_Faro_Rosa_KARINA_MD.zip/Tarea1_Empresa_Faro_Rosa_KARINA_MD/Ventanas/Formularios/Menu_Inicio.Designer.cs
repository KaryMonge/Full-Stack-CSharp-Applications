﻿
namespace Ventanas
{
    partial class Menu_Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu_Inicio));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncerrar = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnsalir = new System.Windows.Forms.Button();
            this.panelmenu = new System.Windows.Forms.Panel();
            this.btn_consultar_inventario = new System.Windows.Forms.Button();
            this.btn_actualizar_inventario = new System.Windows.Forms.Button();
            this.btn_consul_ventas = new System.Windows.Forms.Button();
            this.btn_vent_art = new System.Windows.Forms.Button();
            this.btnreg_vendedores = new System.Windows.Forms.Button();
            this.btnreg_art = new System.Windows.Forms.Button();
            this.panelcentral = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).BeginInit();
            this.panelmenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btncerrar);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1200, 48);
            this.panel1.TabIndex = 1;
            // 
            // btncerrar
            // 
            this.btncerrar.Image = ((System.Drawing.Image)(resources.GetObject("btncerrar.Image")));
            this.btncerrar.Location = new System.Drawing.Point(1152, 3);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(34, 32);
            this.btncerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btncerrar.TabIndex = 2;
            this.btncerrar.TabStop = false;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Calligraphy", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(561, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(411, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "EMPRESA FARO S.A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Calligraphy", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(71, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 27);
            this.label3.TabIndex = 0;
            this.label3.Text = "MENÚ INICIAL";
            // 
            // btnsalir
            // 
            this.btnsalir.BackColor = System.Drawing.Color.Black;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsalir.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold);
            this.btnsalir.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnsalir.Location = new System.Drawing.Point(107, 531);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(157, 34);
            this.btnsalir.TabIndex = 0;
            this.btnsalir.Text = "SALIR";
            this.btnsalir.UseVisualStyleBackColor = false;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // panelmenu
            // 
            this.panelmenu.BackColor = System.Drawing.SystemColors.ControlText;
            this.panelmenu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelmenu.BackgroundImage")));
            this.panelmenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelmenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelmenu.Controls.Add(this.btnsalir);
            this.panelmenu.Controls.Add(this.btn_consultar_inventario);
            this.panelmenu.Controls.Add(this.btn_actualizar_inventario);
            this.panelmenu.Controls.Add(this.btn_consul_ventas);
            this.panelmenu.Controls.Add(this.btn_vent_art);
            this.panelmenu.Controls.Add(this.btnreg_vendedores);
            this.panelmenu.Controls.Add(this.btnreg_art);
            this.panelmenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelmenu.Location = new System.Drawing.Point(0, 48);
            this.panelmenu.Name = "panelmenu";
            this.panelmenu.Size = new System.Drawing.Size(368, 602);
            this.panelmenu.TabIndex = 5;
            // 
            // btn_consultar_inventario
            // 
            this.btn_consultar_inventario.BackColor = System.Drawing.Color.Black;
            this.btn_consultar_inventario.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_consultar_inventario.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold);
            this.btn_consultar_inventario.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_consultar_inventario.Location = new System.Drawing.Point(58, 136);
            this.btn_consultar_inventario.Name = "btn_consultar_inventario";
            this.btn_consultar_inventario.Size = new System.Drawing.Size(238, 34);
            this.btn_consultar_inventario.TabIndex = 6;
            this.btn_consultar_inventario.Text = "Consultar Inventario";
            this.btn_consultar_inventario.UseVisualStyleBackColor = false;
            this.btn_consultar_inventario.Click += new System.EventHandler(this.btn_consultar_inventario_Click);
            // 
            // btn_actualizar_inventario
            // 
            this.btn_actualizar_inventario.BackColor = System.Drawing.Color.Black;
            this.btn_actualizar_inventario.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_actualizar_inventario.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold);
            this.btn_actualizar_inventario.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_actualizar_inventario.Location = new System.Drawing.Point(58, 452);
            this.btn_actualizar_inventario.Name = "btn_actualizar_inventario";
            this.btn_actualizar_inventario.Size = new System.Drawing.Size(238, 34);
            this.btn_actualizar_inventario.TabIndex = 5;
            this.btn_actualizar_inventario.Text = "Actualizar Inventario";
            this.btn_actualizar_inventario.UseVisualStyleBackColor = false;
            this.btn_actualizar_inventario.Click += new System.EventHandler(this.btn_actualizar_inventario_Click);
            // 
            // btn_consul_ventas
            // 
            this.btn_consul_ventas.BackColor = System.Drawing.Color.Black;
            this.btn_consul_ventas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_consul_ventas.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold);
            this.btn_consul_ventas.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_consul_ventas.Location = new System.Drawing.Point(58, 215);
            this.btn_consul_ventas.Name = "btn_consul_ventas";
            this.btn_consul_ventas.Size = new System.Drawing.Size(238, 34);
            this.btn_consul_ventas.TabIndex = 4;
            this.btn_consul_ventas.Text = "Consultar Ventas";
            this.btn_consul_ventas.UseVisualStyleBackColor = false;
            this.btn_consul_ventas.Click += new System.EventHandler(this.btn_consul_ventas_Click);
            // 
            // btn_vent_art
            // 
            this.btn_vent_art.BackColor = System.Drawing.Color.Black;
            this.btn_vent_art.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_vent_art.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_vent_art.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_vent_art.Location = new System.Drawing.Point(58, 294);
            this.btn_vent_art.Name = "btn_vent_art";
            this.btn_vent_art.Size = new System.Drawing.Size(237, 34);
            this.btn_vent_art.TabIndex = 3;
            this.btn_vent_art.Text = " Venta de Artículos";
            this.btn_vent_art.UseVisualStyleBackColor = false;
            this.btn_vent_art.Click += new System.EventHandler(this.btn_vent_art_Click);
            // 
            // btnreg_vendedores
            // 
            this.btnreg_vendedores.BackColor = System.Drawing.Color.Black;
            this.btnreg_vendedores.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnreg_vendedores.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold);
            this.btnreg_vendedores.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnreg_vendedores.Location = new System.Drawing.Point(58, 373);
            this.btnreg_vendedores.Name = "btnreg_vendedores";
            this.btnreg_vendedores.Size = new System.Drawing.Size(237, 34);
            this.btnreg_vendedores.TabIndex = 2;
            this.btnreg_vendedores.Text = "Registrar Vendedores";
            this.btnreg_vendedores.UseVisualStyleBackColor = false;
            this.btnreg_vendedores.Click += new System.EventHandler(this.btnreg_vendedores_Click);
            // 
            // btnreg_art
            // 
            this.btnreg_art.BackColor = System.Drawing.Color.Black;
            this.btnreg_art.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnreg_art.FlatAppearance.BorderSize = 2;
            this.btnreg_art.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkBlue;
            this.btnreg_art.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnreg_art.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreg_art.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnreg_art.Location = new System.Drawing.Point(58, 57);
            this.btnreg_art.Name = "btnreg_art";
            this.btnreg_art.Size = new System.Drawing.Size(238, 34);
            this.btnreg_art.TabIndex = 1;
            this.btnreg_art.Text = "Registrar Artículos";
            this.btnreg_art.UseVisualStyleBackColor = false;
            this.btnreg_art.Click += new System.EventHandler(this.btnreg_art_Click);
            // 
            // panelcentral
            // 
            this.panelcentral.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelcentral.BackgroundImage")));
            this.panelcentral.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelcentral.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelcentral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelcentral.Location = new System.Drawing.Point(368, 48);
            this.panelcentral.Name = "panelcentral";
            this.panelcentral.Size = new System.Drawing.Size(832, 602);
            this.panelcentral.TabIndex = 6;
            // 
            // Menu_Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1200, 650);
            this.Controls.Add(this.panelcentral);
            this.Controls.Add(this.panelmenu);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Menu_Inicio";
            this.Text = "Menu_Inicio";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncerrar)).EndInit();
            this.panelmenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.Panel panelmenu;
        private System.Windows.Forms.Button btn_consultar_inventario;
        private System.Windows.Forms.Button btn_actualizar_inventario;
        private System.Windows.Forms.Button btn_consul_ventas;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_vent_art;
        private System.Windows.Forms.Button btnreg_vendedores;
        private System.Windows.Forms.Button btnreg_art;
        private System.Windows.Forms.PictureBox btncerrar;
        private System.Windows.Forms.Panel panelcentral;
    }
}