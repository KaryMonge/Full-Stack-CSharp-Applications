﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Negocios.Servicios.Funciones_programa;
using static Entidades.Clases.Articulo;
using static Entidades.Clases.OrdenCompra;
using  Entidades.Clases;
using Negocios.Servicios;
namespace Ventanas.Sub_menu
{
    public partial class Venta_Articulos : Form
    {
        public Venta_Articulos()
        {
            InitializeComponent();



            int contador_cedulas = Contador_vendedor();
            contador_compras++;


            if (contador_compras == 21)
            {
                MessageBox.Show("Ya alcanzó el máximo de Compras, no se puede realizar la venta");
                return;
            } else if (contador_cedulas == 0)

            {
                MessageBox.Show("No existen vendedores, no se puede realizar la venta");
                return;
            }
            else
            {
                for (int i = 0; i < contador_cedulas; i++)
                {
                    //  MessageBox.Show("aayyyyyy ÑAÑITOOO" + Vendedor_pos(i));
                    comboBoxid_vendedores.Items.Add(Vendedor_pos(i));
                }
            }

            if (contador_id_ar == 0)
            {
                MessageBox.Show("No existen Artículos, no se puede realizar la venta");
                return;
            }
            else
            {
   
                txt_id_compra.Text = contador_compras.ToString();
                int id_art = 0;
                string descri = "";
                decimal precio_vende = 0;
                decimal precio_fin = 0;
                int cant_disp = 0;
                Boolean activo = false;

                for (int i = 0; i < contador_id_ar; i++)
                {
                    extraer_datos_Articuls(i, ref id_art, ref descri, ref precio_vende, ref precio_fin, ref cant_disp, ref activo);
                    if (activo) {
                        dataGridView_mostrar_articulos.Rows.Add(id_art, descri, precio_vende, precio_fin, cant_disp);
                    }
                }

            }

        }
        //gloviiis juuujuuu
        OrdenCompraDetalle el_carrito = new OrdenCompraDetalle()
        {
            Articulo = new Articulo(),
            Cantidad = 0,

        };
        int contador_detalle = 0;
        int contador_id_ar = Contador_Articulos();
        string id_v;
        string Nomb = "";
        string ape1 = "";
        string ape2 = "";
        DateTime dia = DateTime.Now;

        private void limpiar()
        {
            txt_id_del_articulo.Text = string.Empty;
            txt_cantidad_deseada.Text = string.Empty;

        }

        private void comboBoxid_vendedores_SelectedIndexChanged(object sender, EventArgs e)
        {
            id_v = comboBoxid_vendedores.Text;
            extraer_datos_vendedors(id_v, ref Nomb, ref ape1, ref ape2);
            txt_Nomb_Vend.Text = Nomb;
            txt_1apellido.Text = ape1;
            txt_2pellido.Text = ape2;
            txt_fecha_comp.Text = dia.ToShortDateString();


        }

        private void btnagregar_Click(object sender, EventArgs e)
        {

            try
            {
                if(comboBoxid_vendedores.Text == "")
                {
                 MessageBox.Show("Debe seleccionar un vendedor para realizar la compra.");
                    return;
                }

                if (int.Parse(txt_cantidad_deseada.Text) < 0 ||
                   int.Parse(txt_id_del_articulo.Text) < 0)
                {
                    MessageBox.Show("Por favor, introduzca solo nùmeros positivos.");
                    limpiar();
                    return;
                }     

                if (string.IsNullOrEmpty(txt_id_del_articulo.Text) || string.IsNullOrEmpty(txt_cantidad_deseada.Text))
                {
                    MessageBox.Show("Debe digitar los campos correctamente", "ERROR");
                    limpiar();
                    return;
                }

                if (!Producto_activo_existe(int.Parse(txt_id_del_articulo.Text)))
                {
                    MessageBox.Show("La Identificación " + txt_id_del_articulo.Text + " NO existe", "ERROR");
                    limpiar();
                    return;
                }
                if (cantidad_disponible(int.Parse(txt_id_del_articulo.Text)) < int.Parse(txt_cantidad_deseada.Text))
                {
                    MessageBox.Show("No se puede agregar el artículo, verifique la cantidad disponible", "ERROR");
                    limpiar();
                    return;
                }
                contador_detalle++;

                if (contador_detalle == 16)
                {
                    MessageBox.Show("La orden de compra llegó al máximo de artículos", "ERROR");
                    limpiar();
                    return;
                }
                else

                {

                    string descri = "";
                    decimal precio_vende = 0;
                    decimal precio_fin = 0;
                    int cant_disp = 0;
                    bool activo = true;
                    
                    extraer_datos_Articuls_por_id(int.Parse(txt_id_del_articulo.Text), ref descri, ref precio_vende,
                        ref precio_fin, ref cant_disp, ref activo);

                    el_carrito.Articulo.Id_Articulo = int.Parse(txt_id_del_articulo.Text);
                    el_carrito.Articulo.Descripcion = descri;
                    el_carrito.Articulo.Precio_Vend = precio_vende;
                    el_carrito.Articulo.Precio_Final = precio_fin;

                    el_carrito.Cantidad = int.Parse(txt_cantidad_deseada.Text);
                                        
                    Agregar_compraDetalle(el_carrito);

                    dataGridViewmostrar_elecion.Rows.Add(txt_id_del_articulo.Text, txt_cantidad_deseada.Text);
                    disminuir_cantidad_disponible(int.Parse(txt_id_del_articulo.Text), int.Parse(txt_cantidad_deseada.Text));

                    int id_art = 0;
                    

                    dataGridView_mostrar_articulos.DataSource = null;
                    dataGridView_mostrar_articulos.Rows.Clear();
                    for (int i = 0; i < contador_id_ar; i++)
                    {
                        extraer_datos_Articuls(i, ref id_art, ref descri, ref precio_vende, ref precio_fin, ref cant_disp, ref activo);
                        if (activo)
                        {
                            dataGridView_mostrar_articulos.Rows.Add(id_art, descri, precio_vende, precio_fin, cant_disp);
                        }
                    }

                    var resultado = MessageBox.Show("¿Desea agregrar otro Artículo?", "Agregar", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
                    if (resultado == DialogResult.No)
                    {
                        limpiar();
                        
                    }
                    else
                    {

                        limpiar();
                    }



                }




            }
            catch (Exception)
            {
                MessageBox.Show("Digite los campos solicitados correctamente");
            }

        }

        private void btn_finalizar_Click(object sender, EventArgs e)
        {
           Vendedor VEND = new Vendedor()
           {
                        Ident_Vend = id_v,
                        Nombre_Vend = Nomb,
                        Prim_Apell = ape1,
                        Seg_Apell = ape2,
                        Fecha_Nac = DateTime.MinValue,
                        Genero = '\0',
                        Fecha_ing = DateTime.Today,

           };

           Agregar_compra(int.Parse(txt_id_compra.Text), dia, VEND);



           MessageBox.Show("Se ha realizado la Compra exitosamente", "Finalizado");



        }
    }
}
