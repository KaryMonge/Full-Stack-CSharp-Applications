﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Negocios.Servicios.Funciones_programa;
using static Entidades.Clases.Articulo;
using static Entidades.Clases.OrdenCompra;
using Entidades.Clases;
using Negocios.Servicios;

namespace Ventanas.Sub_menu
{
    public partial class Consulta_Ventas : Form
    {
        public Consulta_Ventas()
        {
            InitializeComponent();

            int contador_compras = Contador_Compras();

            if (contador_compras == 0)

            {
                MessageBox.Show("No existen Compras, no se puede realizar la Consulta");
                return;
            }
            else
            {
                for (int i = 0; i < contador_compras; i++)
                {
                    //  MessageBox.Show("aayyyyyy ÑAÑITOOO" + Vendedor_pos(i));
                    comboBoxid_compra.Items.Add(Compra_pos(i).ToString());
                }
            }

        }

        //mas gloviiiis juju
        int id_compra =0;
              
        private void comboBoxid_compra_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGrid_Consultar_ventas.DataSource = null;
            dataGrid_Consultar_ventas.Rows.Clear();
            id_compra = int.Parse(comboBoxid_compra.Text);
            DateTime fechis = DateTime.Now;
            string idvend = "";
            string nombrecito = "";
            string apell1 = "";
            string apell2 = "";
            int tam_carrito = 0;
            
            extraer_datos_Compra(id_compra, ref fechis, ref idvend, ref nombrecito, ref apell1, ref apell2);

            txtfechacompra.Text = fechis.ToShortDateString();
            txtidvend.Text = idvend;
            txtnombre.Text = nombrecito;
            txt1apell.Text = apell1;
            txt2apell.Text = apell2;

            tam_carrito = tamano_carrito(id_compra);

            int id_articulo = 0;
            string descrip = "";
            int cantidad = 0;
            decimal precio_vende = 0;
            decimal precio_fin = 0;
  
            for (int i=0; i < tam_carrito; i++)
            {
                
                extraer_datos_detalle_compra(id_compra, i, ref id_articulo, ref descrip, 
                    ref cantidad, ref precio_vende, ref precio_fin);
                
                dataGrid_Consultar_ventas.Rows.Add(id_articulo, descrip, cantidad, precio_vende, precio_fin);

            }


        }

        
    }
}
