﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clases;
using Negocios.Servicios;
using static Negocios.Servicios.Funciones_programa;

namespace Ventanas.Sub_menu
{
    public partial class Actualizar_inventario : Form
    {
        public Actualizar_inventario()
        {
            InitializeComponent();
            
            
            

            if (contador_articulo == 0)
            {
                MessageBox.Show("La lista de artículos está vacía");
                return;
            }
            else
            {
                for (int i = 0; i < contador_articulo; i++)
                {
                    //  MessageBox.Show("aayyyyyy ÑAÑITOOO" + Vendedor_pos(i));
                    comboBox_id_iarticulos.Items.Add(Compra_pos(i).ToString());
                }
            }




            for (int i = 0; i < contador_articulo; i++)
            {
                extraer_datos_Articuls(i, ref id_art, ref descri, ref precio_vende, ref precio_fin, ref cant_disp, ref activo);
                if (activo)
                {
                    St_Activo = "Si";
                }
                else
                {
                    St_Activo = "No";
                }

                dataGrid_Lista_Articulos.Rows.Add(id_art, cant_disp, descri, St_Activo, precio_vende, precio_fin);

            }

        }
        //Globales jujis
        int contador_articulo = Contador_Articulos();
        int id_art = 0;
        string descri = "";
        decimal precio_vende = 0;
        decimal precio_fin = 0;
        int cant_disp = 0;
        bool activo = true;
        string St_Activo = "";

        private void btnactualizar_Click(object sender, EventArgs e)
        {
            //aquí se actualizan los datillos chi sheñol


            try
            {
                if (int.Parse(txtnuevacantidad.Text)< 0)
                {
                    MessageBox.Show("No se permiten números negativos");
                    txtnuevacantidad.Text = string.Empty;
                    return;
                }



            }
            catch(Exception)
            {
                MessageBox.Show("Digite el campo correctamente");

               txtnuevacantidad.Text = string.Empty;

            }

            int nueva_cantidad = int.Parse(txtnuevacantidad.Text);

            actualizar_inventario(int.Parse(comboBox_id_iarticulos.Text), nueva_cantidad);

            dataGrid_Lista_Articulos.DataSource = null;
            dataGrid_Lista_Articulos.Rows.Clear();


            for (int i = 0; i < contador_articulo; i++)
            {
                extraer_datos_Articuls(i, ref id_art, ref descri, ref precio_vende, ref precio_fin, ref cant_disp, ref activo);
                if (activo)
                {
                    St_Activo = "Activo";
                }
                else
                {
                    St_Activo = "Inactivo";
                }

                dataGrid_Lista_Articulos.Rows.Add(id_art, cant_disp, descri, St_Activo, precio_vende, precio_fin);

            }




        }

    
    }
}
