﻿using Entidades.Clases;
using Negocios.Servicios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Negocios.Servicios.Funciones_programa;
namespace Ventanas.Sub_menu
{

    public partial class Registro_Vendedores : Form
    {
        public GroupBox Genero { get; private set; }

        public Registro_Vendedores()
        {
            InitializeComponent();
            DateTime dia = DateTime.Now;
            txtFecha_ingreso.Text = dia.ToShortDateString();

        }

        private void limpiar()
        {
            txtid_vendedor.Text = string.Empty;
            txt_Nombre.Text = string.Empty;
            txt_1Apell.Text = string.Empty;
            txt_2Apell.Text = string.Empty; 
        }


        private void btnregistrar_Click(object sender, EventArgs e)
        {
            
               

                try
                {

                    if (Contador_vendedor() == 20)
                    {
                        MessageBox.Show("la lisa de vendedores ya está llena");
                    }



                    char genero = '\0';
                    if (radioButtonF.Checked == true)
                    {
                        genero = 'F';
                    }
                    else if (radioButtonM.Checked == true)
                    {
                        genero = 'M';
                    }
                    else if (radioButtonotro.Checked == true)
                    {
                        genero = 'N';
                    } else { MessageBox.Show("Debe seleccionar un Género"); }


                Vendedor empleado = new Vendedor()
                    {
                        Ident_Vend = txtid_vendedor.Text,
                        Nombre_Vend = txt_Nombre.Text,
                        Prim_Apell = txt_1Apell.Text,
                        Seg_Apell = txt_2Apell.Text,
                        Fecha_Nac = dateTimePicker_Nacimineto.Value,
                        Fecha_ing = DateTime.Parse(txtFecha_ingreso.Text),
                        //Genero = combogenero.SelectedIndex == 0 ? 'F' : combogenero.SelectedIndex == 1 ? 'M' : combogenero.SelectedIndex == 2 ? 'N':
                        Genero = genero,
                    };
         

                    if (string.IsNullOrEmpty(txt_Nombre.Text) || string.IsNullOrEmpty(txt_1Apell.Text) ||
                       string.IsNullOrEmpty(txt_2Apell.Text) || string.IsNullOrEmpty(txtid_vendedor.Text))
                    {
                        MessageBox.Show("Debe digitar los campos correctamente", "ERROR");
                        return;
                    }
                    if (Vendedor_existe(empleado.Ident_Vend))
                    {
                        MessageBox.Show("La Identificación " + txtid_vendedor.Text + " ya existe", "ERROR");
                    }
                    else
                    {


                        Agregar_vendedor(empleado);


                     var resultado = MessageBox.Show("¿Desea agregrar otro Vendedor?", "Agregar", MessageBoxButtons.YesNo,
                      MessageBoxIcon.Question);
                     if (resultado == DialogResult.No)
                     {
                        limpiar();
                     }
                     else
                     {
                        limpiar();
                     }

                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Debe digitar los campos correctamente", "ERROR");
                }
        }

    }
}

