﻿using System;

namespace Ventanas
{
    internal class Consultar_Inventario
    {
       
    }
}