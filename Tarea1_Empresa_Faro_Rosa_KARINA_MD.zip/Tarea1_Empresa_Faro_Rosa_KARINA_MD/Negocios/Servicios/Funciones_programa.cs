﻿using Base_Datos.Arreglo_datos;
using Entidades.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Entidades.Clases.OrdenCompra;

namespace Negocios.Servicios
{
    public static class Funciones_programa

    //----------------------------------------------------------------------------------------------------
    {
        public static int contador_compras = 0;
        //------------------------------------------------------------------------------------------------------
        //
        public static int cantidad_disponible(int id_articulo)
        {
            // Se asume que el artículo existe. si no existe devuelve cero

            for (int i = 0; i < Clase_Arreglos.Lista_Articulos.Length; i++)
            {
                if ((Clase_Arreglos.Lista_Articulos[i] == null))
                {
                    return 0;
                }
                else if (id_articulo.Equals(Clase_Arreglos.Lista_Articulos[i].Id_Articulo))
                {
                    return Clase_Arreglos.Lista_Articulos[i].Cantidad_Disponible;
                }
            }
            return 0;
        }
        public static void disminuir_cantidad_disponible(int id_articulo, int resta)
        {
            //si el artículo existe, se realiza la resta

            for (int i = 0; i < Clase_Arreglos.Lista_Articulos.Length; i++)
            {
                if (id_articulo == Clase_Arreglos.Lista_Articulos[i].Id_Articulo)
                {
                    Clase_Arreglos.Lista_Articulos[i].Cantidad_Disponible = Clase_Arreglos.Lista_Articulos[i].Cantidad_Disponible - resta;
                    return;
                }
            }
        }


        //----------------------------------------------------------------------------------------------------------------------------------------

        // ver si las listas ya están llenas

        public static bool Lista_Articulos_llena()
        {    //valida que este llena en la lista de artículos
            if (Clase_Arreglos.Lista_Articulos.Length == 20) return true;

            return false;
        }
        public static bool Lista_Vendedores_llena()
        {
            //valida que haya espacios diponibles en la lista de Vendedores       
            if (Clase_Arreglos.Lista_Vendedores.Length == 20) return true;
            return false;
        }

        public static bool Lista_Compras_llena()
        {
            //valida que haya espacios diponibles en la lista de compras
            if (Clase_Arreglos.Lista_Compras.Length == 20) return true;
            return false;
        }

        //---------------------------------------------------------------------------------------------------------
        //buscar identificaciones, para localizar o para validar

        public static bool Vendedor_existe(string cedula)
        {  // buscar id de vendedor


            for (int i = 0; i < Clase_Arreglos.Lista_Vendedores.Length; i++)
            {
                if ((Clase_Arreglos.Lista_Vendedores[i] == null)) {
                    //posición i del arreglo, está nula, por lo tanto el objeto de busqueda no se encontró.
                    return false;

                } else if (cedula.Equals(Clase_Arreglos.Lista_Vendedores[i].Ident_Vend)) {
                    //posición i del arreglo contienene el objeto de búsqueda.
                    return true;
                }
            }
            //se recorre el arreglo y no se econtró el objeto.
            return false;
        }


        public static bool Producto_existe(int id_articulo)
        {     // buscar id de producto

            for (int i = 0; i < Clase_Arreglos.Lista_Articulos.Length; i++)
            {
                if ((Clase_Arreglos.Lista_Articulos[i] == null))
                {

                    return false;

                }
                else if (id_articulo.Equals(Clase_Arreglos.Lista_Articulos[i].Id_Articulo))
                {
                    return true;
                }
            }
            return false;
        }

        public static bool Producto_activo_existe(int id_articulo)
        {     // buscar id de producto

            for (int i = 0; i < Clase_Arreglos.Lista_Articulos.Length; i++)
            {
                if ((Clase_Arreglos.Lista_Articulos[i] == null))
                {

                    return false;

                }
                else if (id_articulo.Equals(Clase_Arreglos.Lista_Articulos[i].Id_Articulo))
                {
                    if (Clase_Arreglos.Lista_Articulos[i].Activo)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return false;
        }

        //------------------------------------------------------------------------------------------
        //contadores
        public static int Contador_vendedor()
        {
            //Se asume que el arreglo no está lleno por lo tanto siempre se agrega al final
            Boolean nulo = true;
            int i = 0;

            while (nulo && i < 20)
            {
                if ((Clase_Arreglos.Lista_Vendedores[i] == null))
                {
                    nulo = false;
                }
                else
                {
                    i++;
                }
            }
            return i;
        }

        public static int Contador_Articulos()
        {
            //Se asume que el arreglo no está lleno por lo tanto siempre se agrega al final
            Boolean nulo = true;
            int i = 0;

            while (nulo && i < 20)
            {
                if ((Clase_Arreglos.Lista_Articulos[i] == null))
                {
                    nulo = false;
                }
                else
                {
                    i++;
                }
            }
            return i;
        }

        public static int Contador_Compras()
        {
            //Se asume que el arreglo no está lleno por lo tanto siempre se agrega al final
            Boolean nulo = true;
            int i = 0;

            while (nulo && i < 20)
            {
                if ((Clase_Arreglos.Lista_Compras[i] == null))
                {
                    nulo = false;
                }
                else
                {
                    i++;
                }
            }
            return i;
        }

        //----------------------------------------------------------------------------------------
        // agregar objetos a las listas

        public static void Agregar_vendedor(Vendedor Sujeto)
        {
            //Se asume que el arreglo no está lleno por lo tanto siempre se agrega al final
            Boolean NoInsertado = true;
            int i = 0;

            while (NoInsertado)
            {
                if ((Clase_Arreglos.Lista_Vendedores[i] == null))
                {
                    //posición i del arreglo, está nula, por lo tanto se agrega en la posición i
                    Clase_Arreglos.Lista_Vendedores[i] = Sujeto;
                    NoInsertado = false;
                }
                else
                {
                    i++;
                }
            }

        }

        public static void Agregar_articulo(Articulo Chunchito)
        {
            //Se asume que el arreglo no está lleno por lo tanto siempre se agrega al final
            Boolean NoInsertado = true;
            int i = 0;

            while (NoInsertado)
            {
                if ((Clase_Arreglos.Lista_Articulos[i] == null))
                {
                    //posición i del arreglo, está nula, por lo tanto se agrega en la posición i
                    Clase_Arreglos.Lista_Articulos[i] = Chunchito;
                    NoInsertado = false;
                }
                else
                {
                    i++;
                }
            }

        }
        public static void Agregar_compra(int id_compra, DateTime dia, Vendedor Vend)
        {
            //Se asume que el arreglo no está lleno por lo tanto siempre se agrega al final

            Boolean NoInsertado = true;
            int i = 0;

            OrdenCompra shopping = new OrdenCompra()
            {

                Id_Compra = id_compra,
                Fecha = dia,
                Vendedor = Vend,
                Detalle = Clase_Arreglos.Detalle,

            };


            while (NoInsertado)
            {
                if ((Clase_Arreglos.Lista_Compras[i] == null))
                {
                    //posición i del arreglo, está nula, por lo tanto se agrega en la posición i
                    Clase_Arreglos.Lista_Compras[i] = shopping;
                    NoInsertado = false;
                }
                else
                {
                    i++;
                }
            }

        }

        public static void Agregar_compraDetalle(OrdenCompraDetalle el_cuenton)
        {
            //Se asume que el arreglo no está lleno por lo tanto siempre se agrega al final
            Boolean NoInsertado = true;
            int i = 0;

            while (NoInsertado)
            {
                if ((Clase_Arreglos.Detalle[i] == null))
                {
                    //posición i del arreglo, está nula, por lo tanto se agrega en la posición i
                    Clase_Arreglos.Detalle[i] = el_cuenton;
                    NoInsertado = false;
                }
                else
                {
                    i++;
                }
            }

        }

        //---------------------------------------------------------------------------------------
        //Posición de los arreglos

        public static string Vendedor_pos(int i)
        {  // retorna el vendedor en la posicion i asuminendo su existencia

            return Clase_Arreglos.Lista_Vendedores[i].Ident_Vend;

        }

        public static int Articulo_pos(int i)
        {  // retorna el Articulo en la posicion i asuminendo su existencia

            return Clase_Arreglos.Lista_Articulos[i].Id_Articulo;

        }


        public static int Compra_pos(int i)
        {  // retorna el vendedor en la posicion i asuminendo su existencia

            return Clase_Arreglos.Lista_Articulos[i].Id_Articulo;

        }
        //---------------------------------------------------------------------------------------------------------------

        //edtraer los datos de arrays

        public static void extraer_datos_vendedors(string id_vende, ref string nomb_ved, ref string ape1, ref string ape2)
        {  // retorna los datos del vendedor con e3l id_vende
            int i = 0;
            Boolean Noencontrado = true;


            while (Noencontrado)
            {
                if ((Clase_Arreglos.Lista_Vendedores[i].Ident_Vend == id_vende))
                {
                    //posición i del arreglo contiene el vendedor buscado
                    nomb_ved = Clase_Arreglos.Lista_Vendedores[i].Nombre_Vend;
                    ape1 = Clase_Arreglos.Lista_Vendedores[i].Prim_Apell;
                    ape2 = Clase_Arreglos.Lista_Vendedores[i].Seg_Apell;
                    Noencontrado = false;
                }
                else
                {
                    i++;
                }
            }

        }
        public static void extraer_datos_Compra(int IDcompra, ref DateTime fechis, ref string idvend,
        ref string nombrecito, ref string apell1, ref string apell2)
        {
            int i = 0;
            Boolean Noencontrado = true;


            while (Noencontrado)
            {
                if ((Clase_Arreglos.Lista_Compras[i].Id_Compra == IDcompra))
                {
                    //posición i del arreglo contiene el vendedor buscado
                    fechis = Clase_Arreglos.Lista_Compras[i].Fecha;
                    idvend = Clase_Arreglos.Lista_Compras[i].Vendedor.Ident_Vend;
                    nombrecito = Clase_Arreglos.Lista_Compras[i].Vendedor.Nombre_Vend;
                    apell1 = Clase_Arreglos.Lista_Compras[i].Vendedor.Prim_Apell;
                    apell2 = Clase_Arreglos.Lista_Compras[i].Vendedor.Seg_Apell;
                    Noencontrado = false;
                }
                else
                {
                    i++;
                }
            }

        }


        public static void extraer_datos_Articuls(int i, ref int id_art, ref string descri, ref decimal precio_vende,
            ref decimal precio_fin, ref int cant_disp, ref bool activo)
        {
            //devuelve posicion i
            id_art = Clase_Arreglos.Lista_Articulos[i].Id_Articulo;
            descri = Clase_Arreglos.Lista_Articulos[i].Descripcion;
            precio_vende = Clase_Arreglos.Lista_Articulos[i].Precio_Vend;
            precio_fin = Clase_Arreglos.Lista_Articulos[i].Precio_Final;
            cant_disp = Clase_Arreglos.Lista_Articulos[i].Cantidad_Disponible;
            activo = Clase_Arreglos.Lista_Articulos[i].Activo;


        }

        public static void extraer_datos_Articuls_por_id(int id_art, ref string descri, ref decimal precio_vende,
        ref decimal precio_fin, ref int cant_dis, ref bool activo)
        {
            // Se asume que el artículo existe. si no existe devuelve cero

            for (int i = 0; i < Clase_Arreglos.Lista_Articulos.Length; i++)
            {
                if ((Clase_Arreglos.Lista_Articulos[i] == null))
                {
                    return;
                }
                else if (id_art.Equals(Clase_Arreglos.Lista_Articulos[i].Id_Articulo))
                {
                    descri = Clase_Arreglos.Lista_Articulos[i].Descripcion;
                    precio_vende = Clase_Arreglos.Lista_Articulos[i].Precio_Vend;
                    precio_fin = Clase_Arreglos.Lista_Articulos[i].Precio_Final;
                    cant_dis = Clase_Arreglos.Lista_Articulos[i].Cantidad_Disponible;
                    activo = Clase_Arreglos.Lista_Articulos[i].Activo;
                    return;
                }
            }

        }

        public static void extraer_datos_detalle_compra(int id_compra, int i, ref int id_articulo, ref string descrip,
            ref int cantidad, ref decimal precio_vende, ref decimal precio_fin)
        {
            int j = 0;
            Boolean Noencontrado = true;


            while (Noencontrado)
            {
                if ((Clase_Arreglos.Lista_Compras[j].Id_Compra == id_compra))
                {
                    //posición j del arreglo contiene la compra buscada
                    
                    id_articulo = Clase_Arreglos.Lista_Compras[j].Detalle[i].Articulo.Id_Articulo;
                    descrip = Clase_Arreglos.Lista_Compras[j].Detalle[i].Articulo.Descripcion;
                    cantidad = Clase_Arreglos.Lista_Compras[j].Detalle[i].Cantidad;
                    precio_vende = Clase_Arreglos.Lista_Compras[j].Detalle[i].Articulo.Precio_Vend;
                    precio_fin = Clase_Arreglos.Lista_Compras[j].Detalle[i].Articulo.Precio_Final;
                    Noencontrado = false;
                }
                else
                {
                    j++;
                }
            }

        }

    

        //-------------------------------------------------------------------------------------------------------------
        public static int tamano_carrito(int IDcompra)
        {
            int i = 0;
            Boolean Noencontrado = true;


            while (Noencontrado)
            {
                if ((Clase_Arreglos.Lista_Compras[i].Id_Compra == IDcompra))
                {
                    //posición i del arreglo contiene la compra buscada

                    Boolean nulo = true;
                    int j = 0;

                    while (nulo && j < 15)
                    {
                        if ((Clase_Arreglos.Lista_Compras[i].Detalle[j] == null))
                        {
                            nulo = false;
                        }
                        else
                        {
                            j++;
                        }
                    }
                    return j;
                }
                else
                {
                    i++;
                }
            }
            return 0;

        }


        public static void actualizar_inventario(int id_art, int nueva_cantidad)
        {
            // Se asume que el artículo existe

            for (int i = 0; i < Clase_Arreglos.Lista_Articulos.Length; i++)
            {
                if ((Clase_Arreglos.Lista_Articulos[i] == null))
                {
                    return;
                }
                else if (id_art.Equals(Clase_Arreglos.Lista_Articulos[i].Id_Articulo))
                {
                    Clase_Arreglos.Lista_Articulos[i].Cantidad_Disponible = nueva_cantidad;
                    
                    return;
                }
            }

        }
        //----------------------------------------------------------------------------------------------------------------
        //validar no negativos



    }
}
