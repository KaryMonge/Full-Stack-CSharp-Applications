﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios.Utilidades
{
   public static  class Validaciones_generales
    {

        //validar que no existan negativos



    }
}
