﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clases
{
   public class OrdenCompraDetalle
    {
        //objeto Vendedor
        public Articulo Articulo { get; set; }
        //detalle 
        public int Cantidad { get; set; }

        public OrdenCompraDetalle()
        {
            Articulo = new Articulo();
            Cantidad = 0;

        }

    }
}
