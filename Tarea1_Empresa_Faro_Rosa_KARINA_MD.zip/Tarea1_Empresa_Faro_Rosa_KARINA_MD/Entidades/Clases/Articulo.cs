﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clases
{
    public class Articulo
    {
    public int Id_Articulo { get; set;}

    public string Descripcion { get; set; }

    public bool Activo { get; set; }

        public decimal Precio_Vend { get; set; }

        public decimal Precio_Final { get; set; }

        public int Cantidad_Disponible { get; set; }

        public Articulo()
        {
            Id_Articulo = 0;
            Descripcion = string.Empty;
            Activo = false;
            Precio_Vend = 0;
            Precio_Final = 0;
            Cantidad_Disponible = 0;

        }
    }
}
