﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clases
{
   public class OrdenCompra
    {
        public int Id_Compra { get; set; }

        public DateTime Fecha { get; set; }

        public Vendedor Vendedor { get; set; }
     
        public OrdenCompraDetalle[] Detalle = new OrdenCompraDetalle[15];

        public OrdenCompra()
        {
            Id_Compra = 0;

            Fecha = DateTime.MinValue;

            Vendedor = new Vendedor();

            Detalle = new OrdenCompraDetalle[15];


    }

        
    }
}
